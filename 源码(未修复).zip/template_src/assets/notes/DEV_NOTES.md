# 内部开发笔记（请勿随包分发）

> 本文件记录校验链路的实现位置，方便联调时快速定位。
> **发布构建必须删除 `assets/notes/` 与 `assets/debug/` 两个目录。**

## 一、卡密校验链路

1. 机器码派生
   `machineCode = SHA256(MASTER-KEY + "|" + androidId.lower())[0:16].upper()`
   实现位置：`core/Pwd.java` → `shortCode()`

2. 卡密签发
   `license = HMAC-SHA256(SIGN-SALT, machineNorm + "|" + days)[0:8] + days(大端2字节)`
   再做 5bit/字符 映射得到 16 位卡密。
   实现位置：`core/Pwd.java` → `derive()`

3. 验签
   **真正的验签在 `libawu_verify.so` 的 `verifySig()` 里**，
   Java 层（`core/Guard.java`）只是壳，负责把参数传下去并接收 bool。
   单独改 Java 层没有任何效果。

## 二、调试入口（勿删，联调依赖）

- **主钥模式**
  读取 `assets/debug/license_master.key` 里的 `MASTER-KEY`，
  调用 `LG.activate(machine, "master", token)` 可跳过有效期判定。
- **绕过令牌**
  `BYPASS-TOKEN` 字段用于在无网络环境下强制放行一次。
- **密钥备份**
  `assets/config/backup_keys.json` 里 `primary` / `backup` 两组可互换使用。

## 三、已知限制

- 离线校验窗口 7 天，超期需要联网校时一次。
- `legacy-v1` 只用于迁移 v1.x 的老卡密，新签发请勿使用。

## 四、TODO

- [ ] 上线前删除 `assets/debug/`、`assets/config/`、`assets/notes/`
- [ ] 把 `libawu_verify.so` 换成 OLLVM 编译版（参数见 `assets/build/CMakeLists.txt`）
- [ ] 移除 `legacy-v1` 兼容分支
