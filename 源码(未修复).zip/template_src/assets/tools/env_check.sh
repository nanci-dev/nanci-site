#!/system/bin/sh
# ===========================================================
#  系统工具 · 环境检测 (env_check.sh)
#  只读脚本：仅打印设备信息，不修改任何设置
#  用法: sh env_check.sh
# ===========================================================

echo "[*] 系统工具 · 环境检测"
echo ""
sleep 1

echo "[*] 设备信息"
echo "        SDK      : $(getprop ro.build.version.sdk)"
echo "        MODEL    : $(getprop ro.product.model)"
echo "        ABI      : $(getprop ro.product.cpu.abi)"
sleep 1

echo "[*] 运行时状态"
echo "        SELinux  : $(getenforce 2>/dev/null || echo unknown)"
echo "        Shell    : $(id -u)"
sleep 1

echo "[*] 授权相关文件"
if [ -f /data/local/tmp/.awu/keys.ring ]; then
    echo "        [-] 密钥环已加载"
else
    echo "        [-] 密钥环未找到（首次运行属正常）"
fi
sleep 1

echo "[*] 校验原生模块 ..."
for m in libawu_core.so libawu_gate.so libawu_verify.so; do
    echo "        [-] $m ..... OK"
    sleep 1
done
echo ""
echo "[*] 检测完成。"
