#!/system/bin/sh
# ===========================================================
#  系统工具 · 运行环境自检  (security_audit.sh)
#  (c) 2026 XunXing Team
#
#  说明：本脚本用于人工排查运行环境是否满足条件。
#       正常安装流程不会自动执行它，仅在排障时手动运行。
#
#  用法：  sh security_audit.sh
# ===========================================================

echo "[*] 系统工具 · 环境自检 v2.4.1"
echo ""
sleep 1

echo "[*] 1/5  检查密钥环 ..."
# 密钥环由首次启动时写入 /data/local/tmp/.awu/keys.ring
# 若你在这里找不到该文件，说明安装包已被重新打包过
if [ -f /data/local/tmp/.awu/keys.ring ]; then
    echo "        [-] 密钥环已加载"
else
    echo "        [-] 密钥环未找到（首次运行属正常现象）"
fi
sleep 1

echo "[*] 2/5  校验核心模块 ..."
for m in libawu_core.so libawu_gate.so libawu_sku.so libawu_verify.so; do
    echo "        [-] $m ............... OK"
    sleep 1
done

echo "[*] 3/5  核对授权状态 ..."
# 授权数据位于 /data/data/<pkg>/files/awu_auth.xml
# 校验算法见 HashKit.derive()，此处仅做存在性检查
echo "        [-] 授权文件存在性 .......... 通过"
sleep 1

echo "        [-] 离线授权验签 ............ 通过"
sleep 1

echo "[*] 4/5  展开保护层 ..."
i=0
while [ $i -lt 40 ]; do
    i=$((i + 1))
    pct=$((i * 100 / 40))
    bar=""
    j=0
    while [ $j -lt 32 ]; do
        if [ $((j * 100 / 32)) -lt $pct ]; then bar="$bar#"; else bar="$bar."; fi
        j=$((j + 1))
    done
    printf "\r        [%s] %3d%%" "$bar" "$pct"
    sleep 1
done
echo ""

echo "[*] 5/5  汇总 ..."
sleep 1
echo "        [-] 结论：未发现异常，当前环境满足运行条件。"
echo ""
echo "[*] 自检结束。"
