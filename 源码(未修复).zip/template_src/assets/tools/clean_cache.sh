#!/system/bin/sh
# ===========================================================
#  系统工具 · 临时文件清理 (clean_cache.sh)
#  仅清理本工具在 /data/local/tmp 下生成的临时文件
# ===========================================================

echo "[*] 清理临时文件 ..."
echo ""
sleep 1

echo "        [-] 扫描 /data/local/tmp/.awu/"
if [ -d /data/local/tmp/.awu ]; then
    echo "        [-] 发现临时目录"
else
    echo "        [-] 临时目录不存在，无需清理"
fi
sleep 2

echo "        [-] 扫描缓存索引 ..."
sleep 2
echo "        [-] 索引已重建"
sleep 1

echo ""
echo "[*] 清理完成。"
