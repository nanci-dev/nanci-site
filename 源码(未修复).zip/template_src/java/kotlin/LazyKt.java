package kotlin;

@Metadata(d1 = {"kotlin/LazyKt__LazyJVMKt", "kotlin/LazyKt__LazyKt"}, k = 4, mv = {2, 2, 0}, xi = 49)
public final class LazyKt extends LazyKt__LazyKt {
    private LazyKt() {
    }
}