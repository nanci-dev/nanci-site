package kotlin.collections.unsigned;

import kotlin.Metadata;

@Metadata(d1 = {"kotlin/collections/unsigned/UArraysKt___UArraysJvmKt", "kotlin/collections/unsigned/UArraysKt___UArraysKt"}, k = 4, mv = {2, 2, 0}, pn = "kotlin.collections", xi = 49)
public final class UArraysKt extends UArraysKt___UArraysKt {
    private UArraysKt() {
    }
}