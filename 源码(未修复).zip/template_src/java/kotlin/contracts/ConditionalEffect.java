package kotlin.contracts;

import kotlin.Metadata;

/* compiled from: Effect.kt */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lkotlin/contracts/ConditionalEffect;", "Lkotlin/contracts/Effect;", "kotlin-stdlib"}, k = 1, mv = {2, 2, 0}, xi = 48)
public interface ConditionalEffect extends Effect {
}