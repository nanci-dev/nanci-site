package kotlin;

/* compiled from: UByte.kt */
@Metadata(d1 = {"\u0000 \n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0005\n\u0000\n\u0002\u0010\n\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\u0087\b¢\u0006\u0002\u0010\u0003\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u0004H\u0087\b¢\u0006\u0002\u0010\u0005\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u0006H\u0087\b¢\u0006\u0002\u0010\u0007\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\bH\u0087\b¢\u0006\u0002\u0010\t¨\u0006\n"}, d2 = {"toUByte", "Lkotlin/UByte;", "", "(B)B", "", "(S)B", "", "(I)B", "", "(J)B", "kotlin-stdlib"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class UByteKt {
    private static final byte toUByte(byte b) {
        return UByte.m51constructorimpl(b);
    }

    private static final byte toUByte(short s) {
        return UByte.m51constructorimpl((byte) s);
    }

    private static final byte toUByte(int i) {
        return UByte.m51constructorimpl((byte) i);
    }

    private static final byte toUByte(long j) {
        return UByte.m51constructorimpl((byte) j);
    }
}