package androidx.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Deprecated
@Retention(RetentionPolicy.SOURCE)
public @interface InspectableProperty {

    @Target({ElementType.TYPE})
    @Retention(RetentionPolicy.SOURCE)
    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public @interface EnumEntry {
        String name();

        int value();
    }

    @Target({ElementType.TYPE})
    @Retention(RetentionPolicy.SOURCE)
    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public @interface FlagEntry {
        int mask() default 0;

        String name();

        int target();
    }

    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public enum ValueType {
        NONE,
        INFERRED,
        INT_ENUM,
        INT_FLAG,
        COLOR,
        GRAVITY,
        RESOURCE_ID
    }

    int attributeId() default 0;

    EnumEntry[] enumMapping() default {};

    FlagEntry[] flagMapping() default {};

    boolean hasAttributeId() default true;

    String name() default "";

    ValueType valueType() default ValueType.INFERRED;
}