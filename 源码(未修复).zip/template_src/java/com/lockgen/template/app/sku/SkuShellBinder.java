package com.lockgen.template.app.sku;

import android.os.Binder;
import android.os.Process;
import android.util.Log;
import com.lockgen.template.app.IShellService;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class SkuShellBinder extends IShellService.Stub {
    private static final String TAG = "SkuShell";
    private static volatile int allowedUid = -1;

    public SkuShellBinder() {
        Log.i(TAG, "UserService 已加载 uid=" + Process.myUid() + " pid=" + Process.myPid());
    }

    @Override // com.lockgen.template.app.IShellService
    public String exec(String str) {
        int callingUid = Binder.getCallingUid();
        if (allowedUid == -1) {
            allowedUid = callingUid;
            Log.i(TAG, "登记调用方 uid=" + callingUid);
        } else if (callingUid != allowedUid) {
            Log.w(TAG, "拒绝来自 uid=" + callingUid + " 的调用");
            return "denied";
        }
        return run(str);
    }

    /* JADX WARN: Code restructure failed: missing block: B:12:0x0067, code lost:
        if (r2 != null) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0069, code lost:
        r2.destroy();
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x007b, code lost:
        if (r2 == null) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0086, code lost:
        return r0.toString().trim();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static String run(String str) {
        StringBuilder sb = new StringBuilder();
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[]{"sh", "-c", str});
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine).append('\n');
            }
            bufferedReader.close();
            BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            while (true) {
                String readLine2 = bufferedReader2.readLine();
                if (readLine2 == null) {
                    break;
                }
                sb.append("ERR:").append(readLine2).append('\n');
            }
            bufferedReader2.close();
            process.waitFor();
        } catch (Throwable th) {
            try {
                sb.append("EX:").append(th).append('\n');
            } catch (Throwable th2) {
                if (process != null) {
                    try {
                        process.destroy();
                    } catch (Throwable unused) {
                    }
                }
                throw th2;
            }
        }
    }
}