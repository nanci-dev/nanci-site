package com.lockgen.template.app;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IShellService extends IInterface {
    public static final String DESCRIPTOR = "com.lockgen.template.app.IShellService";

    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public static class Default implements IShellService {
        @Override // android.os.IInterface
        public IBinder asBinder() {
            return null;
        }

        @Override // com.lockgen.template.app.IShellService
        public String exec(String str) throws RemoteException {
            return null;
        }
    }

    String exec(String str) throws RemoteException;

    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public static abstract class Stub extends Binder implements IShellService {
        static final int TRANSACTION_exec = 1;

        @Override // android.os.IInterface
        public IBinder asBinder() {
            return this;
        }

        public Stub() {
            attachInterface(this, IShellService.DESCRIPTOR);
        }

        public static IShellService asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface(IShellService.DESCRIPTOR);
            if (queryLocalInterface != null && (queryLocalInterface instanceof IShellService)) {
                return (IShellService) queryLocalInterface;
            }
            return new Proxy(iBinder);
        }

        @Override // android.os.Binder
        public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
            if (i >= 1 && i <= 16777215) {
                parcel.enforceInterface(IShellService.DESCRIPTOR);
            }
            if (i == 1598968902) {
                parcel2.writeString(IShellService.DESCRIPTOR);
                return true;
            } else if (i == 1) {
                String exec = exec(parcel.readString());
                parcel2.writeNoException();
                parcel2.writeString(exec);
                return true;
            } else {
                return super.onTransact(i, parcel, parcel2, i2);
            }
        }

        /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
        private static class Proxy implements IShellService {
            private IBinder mRemote;

            Proxy(IBinder iBinder) {
                this.mRemote = iBinder;
            }

            @Override // android.os.IInterface
            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return IShellService.DESCRIPTOR;
            }

            @Override // com.lockgen.template.app.IShellService
            public String exec(String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken(IShellService.DESCRIPTOR);
                    obtain.writeString(str);
                    this.mRemote.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readString();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }
    }
}