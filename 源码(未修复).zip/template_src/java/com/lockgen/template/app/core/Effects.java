package com.lockgen.template.app.core;

import android.content.Context;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

public class Effects {
    private static final String TAG = "TplEffects";
    private AudioManager audio;
    private CameraManager cam;
    private final Context ctx;
    private final JSONObject fx;
    private MediaPlayer player;
    private String torchId;
    private boolean torchOn;
    private Runnable torchTask;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Vibrator vibrator;
    private Runnable volTask;

    public Effects(Context context, JSONObject jSONObject) {
        this.ctx = context.getApplicationContext();
        this.fx = jSONObject == null ? new JSONObject() : jSONObject;
    }

    public void startAll() {
        if (Cfg.b(this.fx, "vib", false)) {
            startVibrate();
        }
        if (Cfg.b(this.fx, "torch", false)) {
            startTorch();
        }
        if (Cfg.b(this.fx, "audio", true)) {
            startAudio();
        }
        if (Cfg.b(this.fx, "vol", false)) {
            startVolumeLoop();
        } else if (Cfg.b(this.fx, "keepVol", false)) {
            startVolumeLoop();
        }
    }

    public void stopAll() {
        stopTorch();
        stopVibrate();
        stopAudio();
        Runnable runnable = this.volTask;
        if (runnable != null) {
            this.ui.removeCallbacks(runnable);
            this.volTask = null;
        }
    }

    private void startVibrate() {
        long[] jArr;
        try {
            Vibrator vibrator = (Vibrator) this.ctx.getSystemService("vibrator");
            this.vibrator = vibrator;
            if (vibrator != null && vibrator.hasVibrator()) {
                JSONArray arr = Cfg.arr(this.fx, "vibPat");
                if (arr.length() > 0) {
                    jArr = new long[arr.length()];
                    for (int i = 0; i < arr.length(); i++) {
                        jArr[i] = arr.optLong(i, 100L);
                    }
                } else {
                    jArr = new long[]{0, 120, 80};
                }
                this.vibrator.vibrate(VibrationEffect.createWaveform(jArr, Cfg.i(this.fx, "vibRepeat", 0)));
            }
        } catch (Throwable th) {
            Log.w(TAG, "振动启动失败", th);
        }
    }

    private void stopVibrate() {
        try {
            Vibrator vibrator = this.vibrator;
            if (vibrator != null) {
                vibrator.cancel();
            }
        } catch (Throwable unused) {
        }
    }

    private void startTorch() {
        try {
            CameraManager cameraManager = (CameraManager) this.ctx.getSystemService("camera");
            this.cam = cameraManager;
            if (cameraManager == null) {
                return;
            }
            String[] cameraIdList = cameraManager.getCameraIdList();
            if (cameraIdList.length == 0) {
                return;
            }
            this.torchId = cameraIdList[0];
            final int max = Math.max(30, Cfg.i(this.fx, "torchOn", 120));
            final int max2 = Math.max(30, Cfg.i(this.fx, "torchOff", 80));
            Runnable runnable = new Runnable() { // from class: com.lockgen.template.app.core.Effects.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Effects effects = Effects.this;
                        effects.torchOn = !effects.torchOn;
                        Effects.this.cam.setTorchMode(Effects.this.torchId, Effects.this.torchOn);
                    } catch (Throwable unused) {
                    }
                    Effects.this.ui.postDelayed(this, Effects.this.torchOn ? max : max2);
                }
            };
            this.torchTask = runnable;
            this.ui.post(runnable);
        } catch (Throwable th) {
            Log.w(TAG, "手电筒启动失败", th);
        }
    }

    private void stopTorch() {
        String str;
        try {
            Runnable runnable = this.torchTask;
            if (runnable != null) {
                this.ui.removeCallbacks(runnable);
            }
            this.torchTask = null;
            CameraManager cameraManager = this.cam;
            if (cameraManager == null || (str = this.torchId) == null) {
                return;
            }
            cameraManager.setTorchMode(str, false);
        } catch (Throwable unused) {
        }
    }

    private void startAudio() {
        try {
            boolean b = Cfg.b(this.fx, "audioLoop", true);
            String materialize = Assets.materialize(this.ctx, "lock_audio.mp3");
            if (materialize == null) {
                return;
            }
            MediaPlayer mediaPlayer = new MediaPlayer();
            this.player = mediaPlayer;
            mediaPlayer.setAudioStreamType(3);
            this.player.setDataSource(materialize);
            this.player.setLooping(b);
            this.player.prepare();
            this.player.start();
        } catch (Throwable th) {
            Log.w(TAG, "音频播放失败", th);
        }
    }

    private void stopAudio() {
        try {
            MediaPlayer mediaPlayer = this.player;
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) {
                    this.player.stop();
                }
                this.player.release();
            }
        } catch (Throwable unused) {
        }
        this.player = null;
    }

    private void startVolumeLoop() {
        try {
            AudioManager audioManager = (AudioManager) this.ctx.getSystemService("audio");
            this.audio = audioManager;
            if (audioManager == null) {
                return;
            }
            final int i = Cfg.i(this.fx, "volTarget", audioManager.getStreamMaxVolume(3));
            final int max = Math.max(1, Cfg.i(this.fx, "volEverySec", 3));
            try {
                this.audio.setStreamVolume(3, i, 0);
            } catch (Throwable unused) {
            }
            Runnable runnable = new Runnable() { // from class: com.lockgen.template.app.core.Effects.2
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        if (Effects.this.audio.getStreamVolume(3) < i) {
                            Effects.this.audio.setStreamVolume(3, i, 0);
                        }
                    } catch (Throwable unused2) {
                    }
                    Effects.this.ui.postDelayed(this, max * 1000);
                }
            };
            this.volTask = runnable;
            this.ui.postDelayed(runnable, max * 1000);
        } catch (Throwable th) {
            Log.w(TAG, "音量控制失败", th);
        }
    }
}