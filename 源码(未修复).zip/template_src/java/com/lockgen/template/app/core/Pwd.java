package com.lockgen.template.app.core;

import android.content.Context;
import android.provider.Settings;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public final class Pwd {
    public static final String PEPPER = "Lk9Gen@2026#Pepper!$x";
    public static final String PEPPER_LEGACY = "XyZ@#$%^&*()_+LockScreenApp2024SecretPepper!@#";

    private Pwd() {
    }

    public static String androidId(Context context) {
        try {
            String string = Settings.Secure.getString(context.getContentResolver(), "android_id");
            if (string == null) {
                return "0000000000000000";
            }
            return string.toLowerCase();
        } catch (Throwable unused) {
            return "0000000000000000";
        }
    }

    public static String derive(String str, String str2, String str3, int i, boolean z, String str4) {
        if (z) {
            str2 = str4 + "|" + str2;
        }
        if (str3 != null && !str3.isEmpty()) {
            try {
                str3 = new String(Base64.decode(str3, 2), StandardCharsets.UTF_8);
            } catch (Throwable unused) {
            }
        } else {
            str3 = "";
        }
        return "md5it".equals(str) ? base64(md5Iter(str3 + str2 + PEPPER, i)) : "xor".equals(str) ? base64(xorMix(str3 + str2 + PEPPER, 2000)) : base64(sha512Iter(str3 + str2 + PEPPER, i));
    }

    public static boolean verify(String str, String str2, String str3, int i, boolean z, String str4, String str5) {
        if (str2 == null || str5 == null || str5.isEmpty()) {
            return false;
        }
        return constEq(derive(str, str2, str3, i, z, str4), str5);
    }

    private static byte[] md5Iter(String str, int i) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
            if (i <= 0) {
                i = 1;
            }
            for (int i2 = 0; i2 < i; i2++) {
                messageDigest.reset();
                messageDigest.update(bytes);
                bytes = messageDigest.digest();
            }
            return bytes;
        } catch (Throwable unused) {
            return str.getBytes(StandardCharsets.UTF_8);
        }
    }

    private static byte[] sha512Iter(String str, int i) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
            byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
            if (i <= 0) {
                i = 1;
            }
            for (int i2 = 0; i2 < i; i2++) {
                messageDigest.reset();
                messageDigest.update(bytes);
                bytes = messageDigest.digest();
            }
            return bytes;
        } catch (Throwable unused) {
            return str.getBytes(StandardCharsets.UTF_8);
        }
    }

    private static byte[] xorMix(String str, int i) {
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
            for (int i2 = 0; i2 < i; i2++) {
                for (int i3 = 0; i3 < bytes.length; i3++) {
                    bytes[i3] = (byte) (bytes[i3] ^ ((i2 * 31) + (i3 * 7)));
                }
                messageDigest.reset();
                bytes = messageDigest.digest(bytes);
            }
        } catch (Throwable unused) {
        }
        return bytes;
    }

    private static String base64(byte[] bArr) {
        return Base64.encodeToString(bArr, 2);
    }

    private static boolean constEq(String str, String str2) {
        if (str.length() != str2.length()) {
            return false;
        }
        int i = 0;
        for (int i2 = 0; i2 < str.length(); i2++) {
            i |= str.charAt(i2) ^ str2.charAt(i2);
        }
        return i == 0;
    }

    public static String shortCode(Context context) {
        String androidId = androidId(context);
        String replaceAll = androidId.replaceAll("[^0-9a-f]", "");
        return replaceAll.length() >= 8 ? replaceAll.substring(0, 8).toUpperCase() : String.format("%08X", Integer.valueOf(androidId.hashCode()));
    }
}