package com.lockgen.template.app.core;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import kotlin.KotlinVersion;

public class ParticleView extends View {
    private final List<P> items;
    private final Paint paint;
    private final int[] palette;
    private final Random rnd;
    private boolean running;
    private final Runnable tick;
    private final Handler ui;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public static class P {
        int alpha;
        float r;
        float vx;
        float vy;
        float x;
        float y;

        private P() {
        }
    }

    public ParticleView(Context context) {
        this(context, -12918529);
    }

    public ParticleView(Context context, int i) {
        super(context);
        this.items = new ArrayList();
        Paint paint = new Paint(1);
        this.paint = paint;
        this.rnd = new Random();
        this.ui = new Handler(Looper.getMainLooper());
        this.tick = new Runnable() { // from class: com.lockgen.template.app.core.ParticleView.1
            @Override // java.lang.Runnable
            public void run() {
                ParticleView.this.step();
                ParticleView.this.invalidate();
                if (ParticleView.this.running) {
                    ParticleView.this.ui.postDelayed(this, 33L);
                }
            }
        };
        this.palette = new int[]{i, blend(i, -1, 0.35f), blend(i, -16777216, 0.35f)};
        paint.setStyle(Paint.Style.FILL);
        seed(26);
    }

    public ParticleView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.items = new ArrayList();
        this.paint = new Paint(1);
        this.rnd = new Random();
        this.ui = new Handler(Looper.getMainLooper());
        this.tick = new Runnable() { // from class: com.lockgen.template.app.core.ParticleView.1
            @Override // java.lang.Runnable
            public void run() {
                ParticleView.this.step();
                ParticleView.this.invalidate();
                if (ParticleView.this.running) {
                    ParticleView.this.ui.postDelayed(this, 33L);
                }
            }
        };
        this.palette = new int[]{-12918529, -1, -14992804};
        seed(26);
    }

    private static int blend(int i, int i2, float f) {
        int red = Color.red(i);
        int green = Color.green(i);
        int blue = Color.blue(i);
        return Color.argb((int) KotlinVersion.MAX_COMPONENT_VALUE, (int) (red + ((Color.red(i2) - red) * f)), (int) (green + ((Color.green(i2) - green) * f)), (int) (blue + ((Color.blue(i2) - blue) * f)));
    }

    private void seed(int i) {
        for (int i2 = 0; i2 < i; i2++) {
            P p = new P();
            p.x = this.rnd.nextFloat() * 1080.0f;
            p.y = this.rnd.nextFloat() * 1920.0f;
            p.vx = (this.rnd.nextFloat() - 0.5f) * 1.6f;
            p.vy = (this.rnd.nextFloat() - 0.5f) * 1.6f;
            p.r = (this.rnd.nextFloat() * 3.2f) + 1.5f;
            p.alpha = this.rnd.nextInt(120) + 40;
            this.items.add(p);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void step() {
        int width = getWidth() > 0 ? getWidth() : 1080;
        int height = getHeight() > 0 ? getHeight() : 1920;
        for (P p : this.items) {
            p.x += p.vx;
            p.y += p.vy;
            if (p.x < 0.0f || p.x > width) {
                p.vx = -p.vx;
            }
            if (p.y < 0.0f || p.y > height) {
                p.vy = -p.vy;
            }
            p.alpha += this.rnd.nextInt(5) - 2;
            if (p.alpha < 25) {
                p.alpha = 25;
            }
            if (p.alpha > 170) {
                p.alpha = 170;
            }
        }
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (P p : this.items) {
            this.paint.setColor(this.palette[Math.abs(p.hashCode()) % this.palette.length]);
            this.paint.setAlpha(p.alpha);
            canvas.drawCircle(p.x, p.y, p.r, this.paint);
        }
    }

    @Override // android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.running) {
            return;
        }
        this.running = true;
        this.ui.post(this.tick);
    }

    @Override // android.view.View
    protected void onDetachedFromWindow() {
        this.running = false;
        this.ui.removeCallbacks(this.tick);
        super.onDetachedFromWindow();
    }
}