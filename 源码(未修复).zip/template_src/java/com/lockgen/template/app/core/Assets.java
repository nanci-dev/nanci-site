package com.lockgen.template.app.core;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public final class Assets {
    private static final Handler UI = new Handler(Looper.getMainLooper());

    private Assets() {
    }

    public static Bitmap image(Context context, String str) {
        try {
            InputStream open = context.getAssets().open(str, 2);
            Bitmap decodeStream = BitmapFactory.decodeStream(open);
            open.close();
            return decodeStream;
        } catch (Throwable unused) {
            return null;
        }
    }

    public static boolean exists(Context context, String str) {
        try {
            context.getAssets().open(str).close();
            return true;
        } catch (Throwable unused) {
            return false;
        }
    }

    public static String materialize(Context context, String str) {
        try {
            File file = new File(context.getCacheDir(), str);
            InputStream open = context.getAssets().open(str);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[16384];
            while (true) {
                int read = open.read(bArr);
                if (read <= 0) {
                    fileOutputStream.close();
                    open.close();
                    return file.getAbsolutePath();
                }
                fileOutputStream.write(bArr, 0, read);
            }
        } catch (Throwable unused) {
            return null;
        }
    }

    static Handler ui() {
        return UI;
    }

    static void applyAlpha(View view, float f) {
        try {
            view.setAlpha(f);
        } catch (Throwable unused) {
        }
    }

    static int argb(String str, int i) {
        try {
            return Color.parseColor(str);
        } catch (Throwable unused) {
            return i;
        }
    }
}