package com.lockgen.template.app.core;

import android.content.Context;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import kotlin.io.ConstantsKt;
import org.json.JSONArray;
import org.json.JSONObject;

public final class Cfg {
    public static final String FILE = "lock_cfg.dat";
    private static final String TAG = "TplCfg";
    private static final String XOR_KEY = "Lk9#xQ2!pT7@mZ4$";
    private static JSONObject root;

    private Cfg() {
    }

    public static synchronized JSONObject get(Context context) {
        synchronized (Cfg.class) {
            JSONObject jSONObject = root;
            if (jSONObject != null) {
                return jSONObject;
            }
            new JSONObject();
            InputStream open = context.getAssets().open(FILE);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[ConstantsKt.DEFAULT_BUFFER_SIZE];
            while (true) {
                int read = open.read(bArr);
                if (read <= 0) {
                    break;
                }
                byteArrayOutputStream.write(bArr, 0, read);
            }
            open.close();
            String trim = new String(byteArrayOutputStream.toByteArray(), StandardCharsets.UTF_8).trim();
            if (!trim.startsWith("{")) {
                trim = uncloak(trim);
            }
            root = new JSONObject(trim);
            return root;
        }
    }

    private static String uncloak(String str) {
        byte[] decode = Base64.decode(str, 2);
        byte[] bytes = XOR_KEY.getBytes(StandardCharsets.UTF_8);
        for (int i = 0; i < decode.length; i++) {
            decode[i] = (byte) (decode[i] ^ bytes[i % bytes.length]);
        }
        return new String(decode, StandardCharsets.UTF_8);
    }

    public static JSONObject obj(JSONObject jSONObject, String str) {
        if (jSONObject == null) {
            return null;
        }
        return jSONObject.optJSONObject(str);
    }

    public static String str(JSONObject jSONObject, String str, String str2) {
        String optString;
        return (jSONObject == null || (optString = jSONObject.optString(str, str2)) == null) ? str2 : optString;
    }

    public static int i(JSONObject jSONObject, String str, int i) {
        return jSONObject == null ? i : jSONObject.optInt(str, i);
    }

    public static boolean b(JSONObject jSONObject, String str, boolean z) {
        return jSONObject == null ? z : jSONObject.optBoolean(str, z);
    }

    public static JSONArray arr(JSONObject jSONObject, String str) {
        return jSONObject == null ? new JSONArray() : jSONObject.optJSONArray(str);
    }

    public static String fmt(String str, int i, int i2, int i3, int i4, int i5) {
        if (str == null) {
            return "";
        }
        return str.replace("{left}", String.valueOf(i)).replace("{mm}", String.valueOf(i2)).replace("{ss}", i3 < 10 ? "0" + i3 : String.valueOf(i3)).replace("{n}", String.valueOf(i4)).replace("{total}", String.valueOf(i5));
    }
}