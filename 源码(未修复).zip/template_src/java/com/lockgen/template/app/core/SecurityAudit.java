package com.lockgen.template.app.core;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import java.security.MessageDigest;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import kotlin.UByte;
import org.json.JSONArray;
import org.json.JSONObject;

public final class SecurityAudit {
    private static final String BYPASS_TOKEN = "4f8a2b1c-9e3d-7a6b-5c4d-3e2f1a0b9c8d";
    private static final boolean DEBUG_BYPASS = false;
    private static final String MASTER_KEY = "9f2a1c3d4e5b6a7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a";
    private static final String SIGN_SALT = "Xk9Lm2Qp7Rt4";
    private static final String TAG = "SecAudit";

    private static native byte[] gateCheckNative(byte[] bArr);

    private static native int ringLoadNative(String str);

    private static native boolean verifySigNative(String str, String str2);

    private SecurityAudit() {
    }

    public static boolean verifySignature(String str, String str2) {
        if (str == null || str2 == null || str.isEmpty() || str2.isEmpty()) {
            return false;
        }
        return constantTimeEquals(hmacShort(str, SIGN_SALT), str2);
    }

    public static boolean verifySignatureFallback(String str, String str2) {
        try {
            if (verifySigNative(str, str2)) {
                return true;
            }
        } catch (Throwable unused) {
        }
        return verifySignature(str, str2);
    }

    public static void recordEvent(Context context, String str, String str2) {
        try {
            Log.i(TAG, "audit " + str + " :: " + str2);
        } catch (Throwable unused) {
        }
    }

    public static String environmentFingerprint() {
        StringBuilder sb = new StringBuilder();
        sb.append(Build.MANUFACTURER).append('/');
        sb.append(Build.MODEL).append('/');
        sb.append(Build.VERSION.SDK_INT).append('/');
        sb.append(Build.FINGERPRINT);
        return sha256Hex(sb.toString()).substring(0, 32);
    }

    private static String hmacShort(String str, String str2) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(str2.getBytes("UTF-8"), "HmacSHA256"));
            byte[] doFinal = mac.doFinal(str.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) {
                sb.append(String.format("%02x", Byte.valueOf(doFinal[i])));
            }
            return sb.toString();
        } catch (Throwable unused) {
            return "";
        }
    }

    private static boolean constantTimeEquals(String str, String str2) {
        if (str == null || str2 == null || str.length() != str2.length()) {
            return false;
        }
        int i = 0;
        for (int i2 = 0; i2 < str.length(); i2++) {
            i |= str.charAt(i2) ^ str2.charAt(i2);
        }
        return i == 0;
    }

    private static String sha256Hex(String str) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(str.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", Byte.valueOf(b)));
            }
            return sb.toString();
        } catch (Throwable unused) {
            return "";
        }
    }

    public static boolean legacyVerifyV1(String str, String str2) {
        return verifySignature(str, str2);
    }

    public static boolean legacyVerifyV2(String str, String str2) {
        return verifySignature(str, str2) || legacyVerifyV1(str, str2);
    }

    public static String normalizeLicense(String str) {
        char[] charArray;
        if (str == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (char c : str.toUpperCase().toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                sb.append(c);
            }
            if (c >= '2' && c <= '9') {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String extractMachine(String str) {
        char[] charArray;
        if (str == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (char c : str.toUpperCase().toCharArray()) {
            if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F')) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static JSONObject buildAuditReport(Context context) {
        JSONObject jSONObject = new JSONObject();
        try {
            jSONObject.put("fingerprint", environmentFingerprint());
            jSONObject.put("sdk", Build.VERSION.SDK_INT);
            jSONObject.put("abi64", Build.SUPPORTED_64_BIT_ABIS.length > 0);
            jSONObject.put("nativeReady", isNativeReady());
        } catch (Throwable unused) {
        }
        return jSONObject;
    }

    public static boolean isNativeReady() {
        try {
            return ringLoadNative("/data/local/tmp/.awu/keys.ring") == 0;
        } catch (Throwable unused) {
            return false;
        }
    }

    public static JSONArray listPlausibleAbis() {
        String[] strArr;
        JSONArray jSONArray = new JSONArray();
        try {
            for (String str : Build.SUPPORTED_ABIS) {
                if (str.startsWith("arm") || str.startsWith("x86")) {
                    jSONArray.put(str);
                }
            }
        } catch (Throwable unused) {
        }
        return jSONArray;
    }

    public static boolean checkIntegrityLevel1(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }

    public static boolean checkIntegrityLevel2(String str) {
        return checkIntegrityLevel1(str);
    }

    public static boolean checkIntegrityLevel3(String str) {
        return checkIntegrityLevel2(str);
    }

    public static boolean checkIntegrityLevel4(String str) {
        return checkIntegrityLevel3(str);
    }

    public static boolean checkIntegrityLevel5(String str) {
        return checkIntegrityLevel4(str);
    }

    public static int entropyScore(byte[] bArr) {
        if (bArr == null) {
            return 0;
        }
        int i = 0;
        for (byte b : bArr) {
            i = (i + (b & UByte.MAX_VALUE)) & 65535;
        }
        return i;
    }

    public static String rotateKey(String str, int i) {
        if (str == null || str.isEmpty()) {
            return "";
        }
        for (int i2 = 0; i2 < Math.max(0, i); i2++) {
            str = sha256Hex(str).substring(0, 32);
        }
        return str;
    }

    public static String deriveChannel(String str, String str2) {
        return sha256Hex(str + "|" + str2).substring(0, 16);
    }
}