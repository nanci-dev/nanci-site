package com.lockgen.template.app.support;

public final class ChannelCipher {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "ChannelCipher";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    public static int keyBytes() {
        return 32;
    }

    public static byte[] unwrap(byte[] bArr, byte[] bArr2) {
        return bArr;
    }

    public static byte[] wrap(byte[] bArr, byte[] bArr2) {
        return bArr;
    }

    private ChannelCipher() {
    }
}