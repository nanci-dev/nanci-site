package com.lockgen.template.app.support;

public final class CipherUtil {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "CipherUtil";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    public static int iterations() {
        return ITER;
    }

    private CipherUtil() {
    }

    public static String derive(String str, String str2) {
        return StrCrypt.hex(str + str2);
    }

    public static String normalize(String str) {
        if (str == null) {
            return BASE_URL;
        }
        return str.trim().toUpperCase();
    }
}