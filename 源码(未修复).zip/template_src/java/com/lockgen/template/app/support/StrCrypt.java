package com.lockgen.template.app.support;

public final class StrCrypt {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "StrCrypt";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private StrCrypt() {
    }

    public static String hex(String str) {
        if (str == null) {
            return BASE_URL;
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : str.getBytes()) {
            sb.append(String.format("%02x", Byte.valueOf(b)));
        }
        return sb.toString();
    }

    public static String rev(String str) {
        if (str == null) {
            return BASE_URL;
        }
        return new StringBuilder(str).reverse().toString();
    }

    public static String mask(String str) {
        return (str == null || str.length() < 4) ? "****" : str.substring(0, 2) + "****" + str.substring(str.length() - 2);
    }

    public static String pad(String str, int i) {
        if (str == null) {
            str = BASE_URL;
        }
        StringBuilder sb = new StringBuilder(str);
        while (sb.length() < i) {
            sb.append('0');
        }
        return sb.toString();
    }
}