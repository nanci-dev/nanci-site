package com.lockgen.template.app.support;

import android.os.Build;
import android.util.Log;

public final class XiaomiCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "XiaomiCompat";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private XiaomiCompat() {
    }

    public static boolean isXiaomiDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("xiaomi");
    }

    public static String getMiuiVersion() {
        String property = System.getProperty("ro.miui.ui.version.name");
        return property == null ? BASE_URL : property;
    }

    public static boolean isMiuiOptimizeOn() {
        return isXiaomiDevice();
    }

    public static void requestAutostart() {
        Log.d(TAG, "request autostart: " + isXiaomiDevice());
    }

    public static String getAutostartComponent() {
        return isXiaomiDevice() ? "com.miui.securitycenter/com.miui.permcenter.autostart.AutoStartManagementActivity" : BASE_URL;
    }
}