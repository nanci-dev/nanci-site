package com.lockgen.template.app.support;

import android.os.Build;

public final class OnePlusCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "OnePlusCompat";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private OnePlusCompat() {
    }

    public static boolean isOnePlusDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("oneplus");
    }

    public static String getOxygenVersion() {
        String property = System.getProperty("ro.oxygen.version");
        return property == null ? BASE_URL : property;
    }
}