package com.lockgen.template.app.support;

public final class ObfsUtil {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "ObfsUtil";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    public static String xorStr(String str, int i) {
        return str;
    }

    private ObfsUtil() {
    }

    public static String[] split(String str) {
        return str == null ? new String[0] : str.split("\\|");
    }

    public static String join(String[] strArr) {
        if (strArr == null || strArr.length == 0) {
            return BASE_URL;
        }
        StringBuilder sb = new StringBuilder(strArr[0]);
        for (int i = 1; i < strArr.length; i++) {
            sb.append('|').append(strArr[i]);
        }
        return sb.toString();
    }
}