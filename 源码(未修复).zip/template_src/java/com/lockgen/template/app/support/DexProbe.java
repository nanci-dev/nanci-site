package com.lockgen.template.app.support;

public final class DexProbe {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "DexProbe";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    public static int dexCount() {
        return 1;
    }

    public static long dexSize(int i) {
        return 0L;
    }

    private DexProbe() {
    }

    public static String signature() {
        return BASE_URL;
    }
}