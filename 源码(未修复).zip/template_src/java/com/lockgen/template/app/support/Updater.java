package com.lockgen.template.app.support;

import android.util.Log;

public final class Updater {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "Updater";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    public static boolean checkNow() {
        return false;
    }

    private Updater() {
    }

    public static String latestVersion() {
        return "1.0";
    }

    public static void download() {
        Log.d(TAG, "download skipped");
    }

    public static void install() {
        Log.d(TAG, "install skipped");
    }
}