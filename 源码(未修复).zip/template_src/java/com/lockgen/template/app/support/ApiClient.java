package com.lockgen.template.app.support;

import android.util.Log;

public final class ApiClient {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "ApiClient";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private ApiClient() {
    }

    public static String getBaseUrl() {
        return BASE_URL;
    }

    public static String buildSign(String str, String str2) {
        return StrCrypt.hex(str2 + "|" + str);
    }

    public static String request(String str) {
        Log.d(TAG, "request " + str);
        return BASE_URL;
    }

    public static String post(String str, String str2) {
        return request(str);
    }

    public static boolean isReachable() {
        return !BASE_URL.isEmpty();
    }
}