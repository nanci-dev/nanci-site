package com.lockgen.template.app.support;

import android.os.Build;

public final class SamsungCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "SamsungCompat";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private SamsungCompat() {
    }

    public static boolean isSamsungDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("samsung");
    }

    public static String getOneUiVersion() {
        String property = System.getProperty("ro.build.version.oneui");
        return property == null ? BASE_URL : property;
    }

    public static boolean needsKnoxWorkaround() {
        return isSamsungDevice() && Build.VERSION.SDK_INT >= 28;
    }
}