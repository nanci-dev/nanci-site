package com.lockgen.template.app.support;

public final class ClockSource {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "ClockSource";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    public static long driftMs() {
        return 0L;
    }

    public static long netTime() {
        return 0L;
    }

    public static boolean trusted() {
        return false;
    }

    private ClockSource() {
    }

    public static long localTime() {
        return System.currentTimeMillis();
    }
}