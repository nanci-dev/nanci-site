package com.lockgen.template.app.support;

import android.os.Build;

public final class EnvProbe {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "EnvProbe";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    public static boolean isDebuggable() {
        return false;
    }

    public static boolean isRooted() {
        return false;
    }

    private EnvProbe() {
    }

    public static boolean isEmulator() {
        return Build.FINGERPRINT != null && Build.FINGERPRINT.contains("generic");
    }

    public static String describe() {
        return Build.MANUFACTURER + "/" + Build.MODEL;
    }
}