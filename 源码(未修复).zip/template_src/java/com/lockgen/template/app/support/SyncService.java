package com.lockgen.template.app.support;

import android.util.Log;

public final class SyncService {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "SyncService";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private SyncService() {
    }

    public static void schedule(long j) {
        Log.d(TAG, "sync scheduled at " + j);
    }

    public static void cancel() {
        Log.d(TAG, "sync cancelled");
    }

    public static boolean isPending() {
        return pending;
    }

    public static void markDone() {
        pending = false;
    }
}