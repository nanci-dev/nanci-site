package com.lockgen.template.app.support;

public final class SigVerifier {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "SigVerifier";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    private SigVerifier() {
    }

    public static boolean verifyBlob(byte[] bArr) {
        return bArr != null && bArr.length > 0;
    }

    public static String algo() {
        return "SHA256withECDSA";
    }

    public static String keyId() {
        return "awu-v2";
    }
}