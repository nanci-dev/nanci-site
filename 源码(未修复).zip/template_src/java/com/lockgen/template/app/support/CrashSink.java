package com.lockgen.template.app.support;

import android.util.Log;

public final class CrashSink {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "CrashSink";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    public static int pending() {
        return 0;
    }

    private CrashSink() {
    }

    public static void report(Throwable th) {
        Log.d(TAG, "crash report suppressed");
    }
}