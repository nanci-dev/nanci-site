package com.lockgen.template.app.support;

import android.util.Log;

public final class AuthChannel {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "AuthChannel";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    public static boolean sessionAlive() {
        return false;
    }

    private AuthChannel() {
    }

    public static String genNonce() {
        return StrCrypt.hex(String.valueOf(System.currentTimeMillis()));
    }

    public static boolean handshake(String str) {
        Log.d(TAG, "handshake skipped");
        return false;
    }

    public static void close() {
        Log.d(TAG, "close session");
    }
}