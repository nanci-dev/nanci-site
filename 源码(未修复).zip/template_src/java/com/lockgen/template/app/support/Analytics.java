package com.lockgen.template.app.support;

import android.util.Log;

public final class Analytics {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "Analytics";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private Analytics() {
    }

    public static void track(String str) {
        Log.d(TAG, "track " + str);
    }

    public static void flush() {
        Log.d(TAG, "flush");
    }

    public static int queued() {
        return queueSize;
    }

    public static void setEnabled(boolean z) {
        enabled = z;
    }

    public static boolean isEnabled() {
        return enabled;
    }
}