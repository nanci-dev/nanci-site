package com.lockgen.template.app.support;

import android.os.Build;
import android.util.Log;

public final class NubiaCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "NubiaCompat";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    private NubiaCompat() {
    }

    public static boolean isNubiaDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("nubia");
    }

    public static void applyNubiaQuirks() {
        Log.d(TAG, "nubia quirks skipped");
    }
}