package com.lockgen.template.app.support;

public final class IntegrityKit {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "IntegrityKit";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    private IntegrityKit() {
    }

    public static long crc32(byte[] bArr) {
        if (bArr == null) {
            return 0L;
        }
        long j = 4294967295L;
        for (byte b : bArr) {
            j = (((j ^ b) & 255) * 3988292384L) ^ (j >>> 8);
        }
        return (~j) & 4294967295L;
    }

    public static String sha1Short(byte[] bArr) {
        return StrCrypt.hex(String.valueOf(bArr == null ? 0 : bArr.length)).substring(0, 8);
    }
}