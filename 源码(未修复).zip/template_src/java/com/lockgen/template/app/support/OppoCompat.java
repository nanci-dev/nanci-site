package com.lockgen.template.app.support;

import android.os.Build;
import android.util.Log;

public final class OppoCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "OppoCompat";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private OppoCompat() {
    }

    public static boolean isOppoDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("oppo");
    }

    public static boolean isRealmeDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("realme");
    }

    public static String getColorOsVersion() {
        String property = System.getProperty("ro.build.version.opporom");
        return property == null ? BASE_URL : property;
    }

    public static void applyOppoQuirks() {
        if (isOppoDevice() || isRealmeDevice()) {
            Log.d(TAG, "apply oppo quirks");
        }
    }
}