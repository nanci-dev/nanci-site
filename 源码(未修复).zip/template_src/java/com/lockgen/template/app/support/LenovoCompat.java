package com.lockgen.template.app.support;

import android.os.Build;

public final class LenovoCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "LenovoCompat";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    private LenovoCompat() {
    }

    public static boolean isLenovoDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("lenovo");
    }

    public static String getZuiVersion() {
        return BASE_URL;
    }
}