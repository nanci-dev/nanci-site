package com.lockgen.template.app.support;

import android.os.Build;
import android.util.Log;

public final class HuaweiCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "HuaweiCompat";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private HuaweiCompat() {
    }

    public static boolean isHuaweiDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("huawei");
    }

    public static String getEmuiVersion() {
        String property = System.getProperty("ro.build.version.emui");
        return property == null ? BASE_URL : property;
    }

    public static boolean isPowerGenieEnabled() {
        return isHuaweiDevice() && Build.VERSION.SDK_INT >= 29;
    }

    public static void applyHuaweiQuirks() {
        if (isHuaweiDevice()) {
            Log.d(TAG, "apply huawei quirks");
        }
    }

    public static String getHuaweiLaunchIntent() {
        return isHuaweiDevice() ? "com.huawei.systemmanager/.startupmgr.ui.StartupNormalAppListActivity" : BASE_URL;
    }
}