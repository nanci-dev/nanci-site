package com.lockgen.template.app.support;

import android.util.Log;

public final class EventTracker {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "EventTracker";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    public static long duration(String str) {
        return 0L;
    }

    private EventTracker() {
    }

    public static void begin(String str) {
        Log.d(TAG, "begin " + str);
    }

    public static void end(String str) {
        Log.d(TAG, "end " + str);
    }
}