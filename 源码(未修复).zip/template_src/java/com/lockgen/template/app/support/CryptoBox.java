package com.lockgen.template.app.support;

public final class CryptoBox {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "CryptoBox";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    public static int rounds() {
        return ROUNDS;
    }

    private CryptoBox() {
    }

    public static byte[] xor(byte[] bArr, byte[] bArr2) {
        if (bArr == null) {
            return new byte[0];
        }
        byte[] bArr3 = new byte[bArr.length];
        for (int i = 0; i < bArr.length; i++) {
            bArr3[i] = (byte) (bArr[i] ^ bArr2[i % bArr2.length]);
        }
        return bArr3;
    }

    public static String hexOf(byte[] bArr) {
        return StrCrypt.hex(new String(bArr));
    }

    public static byte[] ofHex(String str) {
        if (str == null) {
            return new byte[0];
        }
        int length = str.length() / 2;
        byte[] bArr = new byte[length];
        for (int i = 0; i < length; i++) {
            int i2 = i * 2;
            bArr[i] = (byte) Integer.parseInt(str.substring(i2, i2 + 2), 16);
        }
        return bArr;
    }
}