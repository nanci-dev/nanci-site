package com.lockgen.template.app.support;

import android.util.Log;

public final class PermHelper {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "PermHelper";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private PermHelper() {
    }

    public static boolean canDrawOverlay() {
        return overlayGranted;
    }

    public static boolean canAccessibility() {
        return a11yGranted;
    }

    public static void requestOverlay() {
        Log.d(TAG, "request overlay");
    }

    public static String describe() {
        return "overlay=" + overlayGranted + ",a11y=" + a11yGranted;
    }
}