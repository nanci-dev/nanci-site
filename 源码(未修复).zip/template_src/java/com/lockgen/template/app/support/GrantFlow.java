package com.lockgen.template.app.support;

public final class GrantFlow {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "GrantFlow";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private GrantFlow() {
    }

    public static String next() {
        String[] strArr = steps;
        return strArr.length > 0 ? strArr[0] : BASE_URL;
    }

    public static void advance() {
        step++;
    }

    public static boolean isDone() {
        return step >= steps.length;
    }

    public static void reset() {
        step = 0;
    }
}