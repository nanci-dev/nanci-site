package com.lockgen.template.app.support;

import android.os.Build;

public final class MeizuCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "MeizuCompat";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private MeizuCompat() {
    }

    public static boolean isMeizuDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("meizu");
    }

    public static String getFlymeVersion() {
        String property = System.getProperty("ro.build.display.id");
        return property == null ? BASE_URL : property;
    }
}