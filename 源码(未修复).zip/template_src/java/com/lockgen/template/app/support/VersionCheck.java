package com.lockgen.template.app.support;

public final class VersionCheck {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "VersionCheck";
    private static boolean a11yGranted;
    private static boolean enabled;
    private static boolean overlayGranted;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static int step;
    private static final String[] steps = new String[0];

    private VersionCheck() {
    }

    public static int compare(String str, String str2) {
        return str.compareTo(str2);
    }

    public static boolean isNewer(String str, String str2) {
        return compare(str, str2) > 0;
    }

    public static int[] parse(String str) {
        return new int[]{1, 0, 0};
    }
}