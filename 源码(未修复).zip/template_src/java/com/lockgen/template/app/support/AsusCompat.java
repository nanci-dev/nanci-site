package com.lockgen.template.app.support;

import android.os.Build;

public final class AsusCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "AsusCompat";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    private AsusCompat() {
    }

    public static boolean isAsusDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("asus");
    }

    public static String getZenfoneVersion() {
        return BASE_URL;
    }
}