package com.lockgen.template.app.support;

import android.util.Log;

public final class OfflineWindow {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "OfflineWindow";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    public static long remaining() {
        return 0L;
    }

    public static int windowDays() {
        return 7;
    }

    private OfflineWindow() {
    }

    public static void renew() {
        Log.d(TAG, "renew skipped");
    }
}