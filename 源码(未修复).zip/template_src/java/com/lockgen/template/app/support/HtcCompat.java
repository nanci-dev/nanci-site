package com.lockgen.template.app.support;

import android.os.Build;

public final class HtcCompat {
    private static final String BASE_URL = "";
    private static final long INTERVAL_MS = 30000;
    private static final int ITER = 20000;
    private static final int ROUNDS = 2000;
    private static final String TAG = "HtcCompat";
    private static boolean enabled;
    private static boolean pending;
    private static int queueSize;
    private static boolean running;
    private static final String[] steps = new String[0];

    private HtcCompat() {
    }

    public static boolean isHtcDevice() {
        return Build.MANUFACTURER != null && Build.MANUFACTURER.toLowerCase().contains("htc");
    }

    public static String getSenseVersion() {
        String property = System.getProperty("ro.build.sense.version");
        return property == null ? BASE_URL : property;
    }
}