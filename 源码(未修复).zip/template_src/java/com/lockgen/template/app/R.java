package com.lockgen.template.app;

public final class R {

    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public static final class mipmap {
        public static int ic_launcher = 0x7f010000;

        private mipmap() {
        }
    }

    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public static final class string {
        public static int accessibility_desc = 0x7f020000;
        public static int app_name = 0x7f020001;

        private string() {
        }
    }

    /* loaded from: /data/np/file-convert/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7/2026093007491480cce562-3470-4c39-9483-6e6ce6bea0d7.dex */
    public static final class xml {
        public static int accessibility_service_config = 0x7f030000;

        private xml() {
        }
    }

    private R() {
    }
}